package com.cdmviewer.schema;

import java.util.Map;

public record SchemaStats(
    int tableCount,
    int relationCount,
    int islandCount,
    int sharedTableCount,
    int isolatedIslandCount,
    int largestIslandSize,
    Map<String, Integer> tableCountByKind,
    Map<String, Integer> relationCountByScope
) {
}
