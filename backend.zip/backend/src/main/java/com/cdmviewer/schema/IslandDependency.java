package com.cdmviewer.schema;

import java.util.List;

public record IslandDependency(
    String sourceIslandId,
    String targetIslandId,
    int relationCount,
    List<String> relationIds
) {
}
