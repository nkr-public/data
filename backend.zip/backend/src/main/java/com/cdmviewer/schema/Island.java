package com.cdmviewer.schema;

import java.util.List;

public record Island(
    String id,
    String proposedName,
    boolean nameOverridden,
    List<String> tableIds
) {
}
