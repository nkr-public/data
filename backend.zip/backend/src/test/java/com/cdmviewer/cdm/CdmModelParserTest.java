package com.cdmviewer.cdm;

import com.cdmviewer.graphml.GraphMlGraph;
import com.cdmviewer.graphml.GraphMlParser;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CdmModelParserTest {

    private static final String SAMPLE_GRAPHML = """
            <?xml version="1.0" encoding="UTF-8"?>
            <graphml xmlns="http://graphml.graphdrawing.org/xmlns" xmlns:y="http://www.yworks.com/xml/graphml">
                <key id="d0" for="node" yfiles.type="nodegraphics"/>
                <key id="d1" for="edge" yfiles.type="edgegraphics"/>
                <graph id="G" edgedefault="directed">
                    <node id="n0">
                        <data key="d0">
                            <y:UMLClassNode>
                                <y:NodeLabel>CUSTOMER</y:NodeLabel>
                                <y:UML>
                                    <y:AttributeLabel>PK id INTEGER
FK1 country_id INTEGER
AK email VARCHAR(100)
name VARCHAR(50)</y:AttributeLabel>
                                </y:UML>
                            </y:UMLClassNode>
                        </data>
                    </node>
                    <node id="n1">
                        <data key="d0">
                            <y:UMLClassNode>
                                <y:NodeLabel>COUNTRY</y:NodeLabel>
                                <y:UML>
                                    <y:AttributeLabel>PK id INTEGER
name VARCHAR(100)</y:AttributeLabel>
                                </y:UML>
                            </y:UMLClassNode>
                        </data>
                    </node>
                    <edge id="e0" source="n0" target="n1">
                        <data key="d1">
                            <y:PolyLineEdge>
                                <y:EdgeLabel>n</y:EdgeLabel>
                                <y:EdgeLabel>1</y:EdgeLabel>
                            </y:PolyLineEdge>
                        </data>
                    </edge>
                </graph>
            </graphml>
            """;

    @Test
    void convertsGraphMlIntoTablesColumnsAndRelations() {
        GraphMlParser graphMlParser = new GraphMlParser();
        InputStream inputStream = new ByteArrayInputStream(SAMPLE_GRAPHML.getBytes(StandardCharsets.UTF_8));
        GraphMlGraph graph = graphMlParser.parse(inputStream);

        CdmModel model = new CdmModelParser().parse(graph);

        assertEquals(2, model.getTables().size());

        Table customer = model.getTables().get(0);
        assertEquals("CUSTOMER", customer.getTable());
        List<Column> columns = customer.getColumns();
        assertEquals(4, columns.size());

        assertEquals("id", columns.get(0).getName());
        assertEquals("INTEGER", columns.get(0).getType());
        assertEquals(ColumnCategory.ID, columns.get(0).getCategory());

        assertEquals("country_id", columns.get(1).getName());
        assertEquals(ColumnCategory.EXTERNAL, columns.get(1).getCategory());

        assertEquals("email", columns.get(2).getName());
        assertEquals(ColumnCategory.INDEX, columns.get(2).getCategory());

        assertEquals("name", columns.get(3).getName());
        assertEquals(ColumnCategory.NONE, columns.get(3).getCategory());

        Table country = model.getTables().get(1);
        assertEquals("COUNTRY", country.getTable());
        assertEquals(2, country.getColumns().size());

        assertEquals(1, model.getRelations().size());
        Relation relation = model.getRelations().get(0);
        assertEquals("CUSTOMER", relation.getSourceTable());
        assertEquals("COUNTRY", relation.getTargetTable());
        assertEquals("n", relation.getSourceCardinality());
        assertEquals("1", relation.getTargetCardinality());
        assertEquals("n:1", relation.getCardinality());
    }

    private static final String UML_CLASS_MODEL_GRAPHML = """
            <?xml version="1.0" encoding="UTF-8"?>
            <graphml xmlns="http://graphml.graphdrawing.org/xmlns"
                     xmlns:uml="http://www.yworks.com/xml/uml"
                     xmlns:x="http://www.yworks.com/xml/yfiles-common/markup/2.0"
                     xmlns:sys="http://www.yworks.com/xml/yfiles-common/system/1.0">
                <key id="d7" for="node"/>
                <graph id="G" edgedefault="directed">
                    <node id="node35">
                        <data key="d7">
                            <uml:UMLNodeStyle>
                                <uml:UMLNodeStyle.model>
                                    <uml:UMLClassModel className="com_agency_address">
                                        <uml:UMLClassModel.attributes>
                                            <x:Array Type="sys:Object">
                                                <sys:String>COMPANY_ID: bigint</sys:String>
                                                <sys:String>ID: bigint</sys:String>
                                            </x:Array>
                                        </uml:UMLClassModel.attributes>
                                        <uml:UMLClassModel.operations>
                                            <x:Array Type="sys:Object">
                                                <sys:String>CODE: varchar(64)</sys:String>
                                                <sys:String>CREATED_AT: datetime(6)</sys:String>
                                            </x:Array>
                                        </uml:UMLClassModel.operations>
                                    </uml:UMLClassModel>
                                </uml:UMLNodeStyle.model>
                            </uml:UMLNodeStyle>
                        </data>
                    </node>
                </graph>
            </graphml>
            """;

    @Test
    void convertsUmlClassModelNodeIntoTableAndColumns() {
        GraphMlParser graphMlParser = new GraphMlParser();
        InputStream inputStream = new ByteArrayInputStream(UML_CLASS_MODEL_GRAPHML.getBytes(StandardCharsets.UTF_8));
        GraphMlGraph graph = graphMlParser.parse(inputStream);

        CdmModel model = new CdmModelParser().parse(graph);

        assertEquals(1, model.getTables().size());
        Table table = model.getTables().get(0);
        assertEquals("com_agency_address", table.getTable());

        List<Column> columns = table.getColumns();
        assertEquals(4, columns.size());
        assertEquals("COMPANY_ID", columns.get(0).getName());
        assertEquals("bigint", columns.get(0).getType());
        assertEquals("ID", columns.get(1).getName());
        assertEquals("CODE", columns.get(2).getName());
        assertEquals("varchar(64)", columns.get(2).getType());
        assertEquals("CREATED_AT", columns.get(3).getName());
        assertEquals("datetime(6)", columns.get(3).getType());
    }

    @Test
    void serializesModelToJson() throws Exception {
        GraphMlParser graphMlParser = new GraphMlParser();
        InputStream inputStream = new ByteArrayInputStream(SAMPLE_GRAPHML.getBytes(StandardCharsets.UTF_8));
        GraphMlGraph graph = graphMlParser.parse(inputStream);
        CdmModel model = new CdmModelParser().parse(graph);

        String json = new CdmModelJsonWriter().toJson(model);

        assertTrue(json.contains("\"table\" : \"CUSTOMER\""));
        assertTrue(json.contains("\"category\" : \"id\""));
        assertTrue(json.contains("\"relations\""));
    }
}
