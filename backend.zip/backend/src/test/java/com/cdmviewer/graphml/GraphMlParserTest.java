package com.cdmviewer.graphml;

import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class GraphMlParserTest {

    private static final String SAMPLE_GRAPHML = """
            <?xml version="1.0" encoding="UTF-8"?>
            <graphml xmlns="http://graphml.graphdrawing.org/xmlns">
                <key id="d0" for="node" attr.name="label" attr.type="string"/>
                <key id="d1" for="edge" attr.name="weight" attr.type="double"/>
                <graph id="G" edgedefault="directed">
                    <node id="n0">
                        <data key="d0">Node 0</data>
                    </node>
                    <node id="n1">
                        <data key="d0">Node 1</data>
                    </node>
                    <edge id="e0" source="n0" target="n1">
                        <data key="d1">2.5</data>
                    </edge>
                </graph>
            </graphml>
            """;

    @Test
    void parsesNodesEdgesAndData() {
        GraphMlParser parser = new GraphMlParser();
        InputStream inputStream = new ByteArrayInputStream(SAMPLE_GRAPHML.getBytes(StandardCharsets.UTF_8));

        GraphMlGraph graph = parser.parse(inputStream);

        assertEquals("G", graph.getId());
        assertEquals("directed", graph.getEdgeDefault());
        assertEquals(2, graph.getNodes().size());
        assertEquals(1, graph.getEdges().size());

        GraphMlNode node0 = graph.getNodes().get(0);
        assertEquals("n0", node0.getId());
        assertEquals("Node 0", node0.getData("label"));

        GraphMlEdge edge0 = graph.getEdges().get(0);
        assertEquals("e0", edge0.getId());
        assertEquals("n0", edge0.getSource());
        assertEquals("n1", edge0.getTarget());
        assertEquals("2.5", edge0.getData("weight"));
    }

    @Test
    void throwsWhenGraphElementMissing() {
        String invalid = "<graphml xmlns=\"http://graphml.graphdrawing.org/xmlns\"></graphml>";
        GraphMlParser parser = new GraphMlParser();
        InputStream inputStream = new ByteArrayInputStream(invalid.getBytes(StandardCharsets.UTF_8));

        GraphMlParseException exception = assertThrows(GraphMlParseException.class, () -> parser.parse(inputStream));
        assertTrue(exception.getMessage().contains("graph"));
    }

    @Test
    void throwsWhenRootElementInvalid() {
        String invalid = "<notgraphml></notgraphml>";
        GraphMlParser parser = new GraphMlParser();
        InputStream inputStream = new ByteArrayInputStream(invalid.getBytes(StandardCharsets.UTF_8));

        assertThrows(GraphMlParseException.class, () -> parser.parse(inputStream));
    }
}
