/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["selector", '[data-theme="dark"], .dark'],
  content: [
    "./src/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        background: "rgb(var(--color-background) / <alpha-value>)",
        surface: "rgb(var(--color-surface) / <alpha-value>)",
        foreground: "rgb(var(--color-foreground) / <alpha-value>)",
        "foreground-muted": "rgb(var(--color-muted-foreground) / <alpha-value>)",
        primary: {
          DEFAULT: "rgb(var(--color-primary) / <alpha-value>)",
          hover: "rgb(var(--color-primary-hover, var(--color-primary)) / <alpha-value>)",
          foreground: "rgb(var(--color-primary-foreground) / <alpha-value>)"
        },
        "primary-foreground": "rgb(var(--color-primary-foreground) / <alpha-value>)",
        border: "rgb(var(--color-border) / <alpha-value>)"
      },
      borderRadius: {
        sm: "var(--radius-sm, 0.25rem)",
        md: "var(--radius-md, 0.5rem)",
        lg: "var(--radius-lg, 0.75rem)"
      },
      boxShadow: {
        primary: "var(--shadow-primary)"
      },
      fontFamily: {
        sans: "var(--font-sans, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Inter, sans-serif)",
        mono: "var(--font-mono, ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace)"
      }
    }
  },
  plugins: []
};
