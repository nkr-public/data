export interface Column {
    name: string;
    type: string;
    category: string;
}

export interface Table {
    id: string;
    table: string;
    columns: Column[];
}

export interface Relation {
    id: string;
    name: string;
    sourceTable: string;
    targetTable: string;
    sourceCardinality: string;
    targetCardinality: string;
}

export interface CdmModel {
    tables: Table[];
    relations: Relation[];
    clusters?: string[][];
}

export interface SchemaExportRequest {
    type: string;
    url: string;
    username: string;
    password: string;
    schema: string;
}

export interface SavedSchema extends SchemaExportRequest {
    id: string;
    label: string;
}
