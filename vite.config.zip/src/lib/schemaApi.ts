import type { CdmModel, SchemaExportRequest } from "./cdmTypes";

export async function exportSchema(request: SchemaExportRequest): Promise<CdmModel> {
    const response = await fetch("/api/schema/export", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(request)
    });

    if (!response.ok) {
        const text = await response.text().catch(() => "");
        throw new Error(text || `Erreur ${response.status} lors de l'export du schéma`);
    }

    return (await response.json()) as CdmModel;
}
