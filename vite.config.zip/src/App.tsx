import { HashRouter, Route, Routes } from "react-router-dom";
import AppLayout from "./app/layout";
import HomePage from "./app/page";
import { SchemaViewerPage } from "./app/components/SchemaViewerPage";
import { SchemaProvider } from "./app/components/SchemaContext";
import "./app/globals.css";

export default function App() {
  return (
    <HashRouter>
      <SchemaProvider>
        <AppLayout>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/schemaViewer" element={<SchemaViewerPage />} />
          </Routes>
        </AppLayout>
      </SchemaProvider>
    </HashRouter>
  );
}
