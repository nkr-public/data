import type { ReactNode } from "react";
import { useLocation } from "react-router-dom";
import { TitleBar } from "./components/TitleBar";

export default function AppLayout({ children }: { children: ReactNode }) {
    const location = useLocation();
    const isFullScreenRoute = location.pathname === "/schemaViewer";

    return (
        <div className="min-h-screen flex flex-col">
            <TitleBar />

            {isFullScreenRoute ? (
                <main className="flex-1 relative overflow-hidden">{children}</main>
            ) : (
                <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
                    {children}
                </main>
            )}
        </div>
    );
}
