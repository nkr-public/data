export default function HomePage() {
    return (
        <div className="rounded-lg bg-surface p-6">
            <h1 className="text-2xl font-bold text-foreground">CDM Viewer</h1>
            <p className="text-foreground-muted mt-2">
                Bienvenue. Cette page est un point de départ vide, prêt à accueillir vos futurs écrans.
            </p>
        </div>
    );
}
