import React, { createContext, useCallback, useContext, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { CdmModel } from "../../lib/cdmTypes";

interface SchemaContextValue {
    isMenuOpen: boolean;
    openMenu: () => void;
    closeMenu: () => void;
    model: CdmModel | null;
    showModel: (model: CdmModel) => void;
    closeViewer: () => void;
}

const SchemaContext = createContext<SchemaContextValue | null>(null);

export function SchemaProvider({ children }: { children: React.ReactNode }) {
    const [isMenuOpen, setMenuOpen] = useState(false);
    const [model, setModel] = useState<CdmModel | null>(null);
    const navigate = useNavigate();

    const openMenu = useCallback(() => setMenuOpen(true), []);
    const closeMenu = useCallback(() => setMenuOpen(false), []);
    const showModel = useCallback((next: CdmModel) => {
        setModel(next);
        setMenuOpen(false);
        navigate("/schemaViewer");
    }, [navigate]);
    const closeViewer = useCallback(() => {
        setModel(null);
        navigate("/");
    }, [navigate]);

    const value = useMemo(
        () => ({ isMenuOpen, openMenu, closeMenu, model, showModel, closeViewer }),
        [isMenuOpen, openMenu, closeMenu, model, showModel, closeViewer]
    );

    return <SchemaContext.Provider value={value}>{children}</SchemaContext.Provider>;
}

export function useSchemaContext(): SchemaContextValue {
    const ctx = useContext(SchemaContext);
    if (!ctx) {
        throw new Error("useSchemaContext must be used within a SchemaProvider");
    }
    return ctx;
}
