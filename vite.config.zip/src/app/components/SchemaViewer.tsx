import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import ReactFlow, {
    applyNodeChanges,
    Background,
    Controls,
    type Edge,
    type Node,
    type NodeChange,
    ReactFlowProvider,
    useReactFlow
} from "reactflow";
import "reactflow/dist/style.css";
import { useSchemaContext } from "./SchemaContext";
import { TableNode, type TableNodeData } from "./TableNode";
import { assignEdgeHandles, layoutGraph } from "@/lib/elkLayout";
import { ClusterMenu, type ClusterInfo } from "./ClusterMenu";
import { DependencyPopup } from "./DependencyPopup";

const nodeTypes = { table: TableNode };

/** Seules les colonnes de ces catégories sont affichées dans les tables. */
const VISIBLE_COLUMN_CATEGORIES = new Set(["id", "external"]);

/** Couleur des liaisons et tables "allumées" (survolées). */
const HIGHLIGHT_COLOR = "#f59e0b";
/**
 * Ordre d'empilement des éléments allumés : au-dessus de tout le reste, avec
 * les liaisons au-dessus des tables. React Flow dessine la couche des liaisons
 * avant celle des nœuds, donc à z-index égal une table masquerait la liaison.
 * Le libellé est dessiné dans le même groupe SVG que le tracé, après lui, et se
 * retrouve donc toujours au-dessus du trait.
 */
const HIGHLIGHT_NODE_Z_INDEX = 1000;
const HIGHLIGHT_EDGE_Z_INDEX = HIGHLIGHT_NODE_Z_INDEX + 1;

interface Highlight {
    nodeIds: Set<string>;
    edgeIds: Set<string>;
}

const EMPTY_HIGHLIGHT: Highlight = { nodeIds: new Set(), edgeIds: new Set() };

/** Menu contextuel ouvert par clic droit sur l'en-tête d'une table. */
interface NodeContextMenu {
    nodeId: string;
    x: number;
    y: number;
}

function SchemaViewerInner() {
    const { model } = useSchemaContext();
    const [selectedClusterId, setSelectedClusterId] = useState<number | null>(null);
    const [nodes, setNodes] = useState<Node<TableNodeData>[]>([]);
    const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null);
    const [hoveredEdgeId, setHoveredEdgeId] = useState<string | null>(null);
    const [contextMenu, setContextMenu] = useState<NodeContextMenu | null>(null);
    const [dependencyTableId, setDependencyTableId] = useState<string | null>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const { fitView } = useReactFlow();

    // Construction de la liste des clusters
    const clusters: ClusterInfo[] = useMemo(() => {
        if (!model) return [];
        if (model.clusters && model.clusters.length > 0) {
            return model.clusters.map((clusterTables, index) => ({
                id: index,
                name: `Cluster ${index + 1}`,
                tableIds: clusterTables
            }));
        }
        // Fallback si pas de clusters renseignés
        return [
            {
                id: 0,
                name: "Tous les éléments",
                tableIds: model.tables.map((t) => t.id)
            }
        ];
    }, [model]);

    // Initialisation ou mise à jour du cluster sélectionné
    useEffect(() => {
        if (clusters.length > 0) {
            setSelectedClusterId((prev) => {
                if (prev !== null && clusters.some((c) => c.id === prev)) {
                    return prev;
                }
                return clusters[0].id;
            });
        } else {
            setSelectedClusterId(null);
        }
    }, [clusters]);

    // Ensemble des tables du cluster sélectionné
    const currentClusterTableSet = useMemo(() => {
        if (!model || selectedClusterId === null) return new Set<string>();
        const targetCluster = clusters.find((c) => c.id === selectedClusterId);
        if (!targetCluster) return new Set<string>();
        return new Set(targetCluster.tableIds);
    }, [model, clusters, selectedClusterId]);

    // Filtrage des relations appartenant au cluster sélectionné
    const edges: Edge[] = useMemo(() => {
        if (!model || currentClusterTableSet.size === 0) return [];
        return model.relations
            .filter(
                (rel) =>
                    currentClusterTableSet.has(rel.sourceTable) &&
                    currentClusterTableSet.has(rel.targetTable)
            )
            .map((relation) => ({
                id: relation.id,
                source: relation.sourceTable,
                target: relation.targetTable,
                animated: false,
                type: "smoothstep",
                label: relation.name
            }));
    }, [model, currentClusterTableSet]);

    // Zone du graphe "allumée" : la table survolée, ses liaisons et les tables
    // associées, ou bien la liaison survolée et ses deux tables.
    const highlight: Highlight = useMemo(() => {
        if (hoveredNodeId !== null) {
            const nodeIds = new Set<string>([hoveredNodeId]);
            const edgeIds = new Set<string>();
            for (const edge of edges) {
                if (edge.source === hoveredNodeId || edge.target === hoveredNodeId) {
                    edgeIds.add(edge.id);
                    nodeIds.add(edge.source);
                    nodeIds.add(edge.target);
                }
            }
            return { nodeIds, edgeIds };
        }
        if (hoveredEdgeId !== null) {
            const edge = edges.find((e) => e.id === hoveredEdgeId);
            if (edge) {
                return {
                    nodeIds: new Set([edge.source, edge.target]),
                    edgeIds: new Set([edge.id])
                };
            }
        }
        return EMPTY_HIGHLIGHT;
    }, [edges, hoveredNodeId, hoveredEdgeId]);

    const isHighlightActive = highlight.edgeIds.size > 0 || highlight.nodeIds.size > 0;

    // Nœuds affichés : état allumé/atténué injecté dans les données
    const displayNodes: Node<TableNodeData>[] = useMemo(
        () =>
            nodes.map((node) => {
                const highlighted = highlight.nodeIds.has(node.id);
                const dimmed = isHighlightActive && !highlighted;
                if (!node.data.highlighted === !highlighted && !node.data.dimmed === !dimmed) {
                    return node;
                }
                return {
                    ...node,
                    zIndex: highlighted ? HIGHLIGHT_NODE_Z_INDEX : undefined,
                    data: { ...node.data, highlighted, dimmed }
                };
            }),
        [nodes, highlight, isHighlightActive]
    );

    // Liaisons affichées : handles choisis selon la position courante des
    // tables, libellé visible uniquement lorsque la liaison est allumée.
    const displayEdges: Edge[] = useMemo(
        () =>
            assignEdgeHandles(nodes, edges).map((edge) => {
                const highlighted = highlight.edgeIds.has(edge.id);
                return {
                    ...edge,
                    label: highlighted ? edge.label : undefined,
                    zIndex: highlighted ? HIGHLIGHT_EDGE_Z_INDEX : undefined,
                    interactionWidth: 20,
                    style: highlighted
                        ? { stroke: HIGHLIGHT_COLOR, strokeWidth: 2.5 }
                        : { opacity: isHighlightActive ? 0.25 : 1 },
                    labelBgPadding: [4, 2] as [number, number],
                    labelBgBorderRadius: 4,
                    labelStyle: { fontSize: 11, fontWeight: 600, fill: HIGHLIGHT_COLOR },
                    labelBgStyle: { fill: "hsl(var(--background))", fillOpacity: 0.95 }
                };
            }),
        [nodes, edges, highlight, isHighlightActive]
    );

    const onNodesChange = useCallback((changes: NodeChange[]) => {
        setNodes((current) => applyNodeChanges(changes, current) as Node<TableNodeData>[]);
    }, []);

    const onNodeMouseEnter = useCallback((_: React.MouseEvent, node: Node) => {
        setHoveredNodeId(node.id);
    }, []);
    const onNodeMouseLeave = useCallback(() => setHoveredNodeId(null), []);
    const onEdgeMouseEnter = useCallback((_: React.MouseEvent, edge: Edge) => {
        setHoveredEdgeId(edge.id);
    }, []);
    const onEdgeMouseLeave = useCallback(() => setHoveredEdgeId(null), []);

    // Clic droit sur une table : le menu n'est ouvert que depuis l'en-tête.
    const onNodeContextMenu = useCallback((event: React.MouseEvent, node: Node) => {
        event.preventDefault();
        const target = event.target as HTMLElement | null;
        if (!target?.closest("[data-table-header]")) {
            setContextMenu(null);
            return;
        }
        const rect = containerRef.current?.getBoundingClientRect();
        setContextMenu({
            nodeId: node.id,
            x: event.clientX - (rect?.left ?? 0),
            y: event.clientY - (rect?.top ?? 0)
        });
    }, []);
    const closeContextMenu = useCallback(() => setContextMenu(null), []);
    const closeDependencyPopup = useCallback(() => setDependencyTableId(null), []);

    // Fermeture du menu contextuel au clic ailleurs ou sur Échap
    useEffect(() => {
        if (!contextMenu) return;
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === "Escape") setContextMenu(null);
        };
        window.addEventListener("mousedown", closeContextMenu);
        window.addEventListener("keydown", handleKeyDown);
        return () => {
            window.removeEventListener("mousedown", closeContextMenu);
            window.removeEventListener("keydown", handleKeyDown);
        };
    }, [contextMenu, closeContextMenu]);

    // Mise en page du cluster sélectionné
    useEffect(() => {
        setHoveredNodeId(null);
        setHoveredEdgeId(null);
        setContextMenu(null);
        if (!model || currentClusterTableSet.size === 0) {
            setNodes([]);
            return;
        }

        const filteredTables = model.tables.filter((t) => currentClusterTableSet.has(t.id));

        const baseNodes: Node<TableNodeData>[] = filteredTables.map((table) => ({
            id: table.id,
            type: "table",
            position: { x: 0, y: 0 },
            data: {
                table: table.table,
                columns: table.columns.filter((column) => VISIBLE_COLUMN_CATEGORIES.has(column.category))
            }
        }));

        const rect = containerRef.current?.getBoundingClientRect();
        const viewerDimensions = rect
            ? { width: rect.width, height: rect.height }
            : { width: window.innerWidth, height: window.innerHeight };

        let cancelled = false;
        let timeoutId: ReturnType<typeof setTimeout> | undefined;

        layoutGraph(baseNodes, edges, viewerDimensions).then((laidOut) => {
            if (cancelled) return;
            setNodes(laidOut as Node<TableNodeData>[]);

            // Recentrage sur le cluster
            timeoutId = setTimeout(() => {
                fitView({ padding: 0.02, duration: 300 });
            }, 50);
        });

        return () => {
            cancelled = true;
            if (timeoutId) clearTimeout(timeoutId);
        };
    }, [model, currentClusterTableSet, edges, fitView]);

    const handleSelectCluster = (clusterId: number) => {
        setSelectedClusterId(clusterId);
    };

    if (!model) {
        return null;
    }

    return (
        <div ref={containerRef} className="absolute inset-0 z-[10] bg-background">
            <ClusterMenu
                clusters={clusters}
                selectedClusterId={selectedClusterId}
                onSelectCluster={handleSelectCluster}
            />

            <ReactFlow
                nodes={displayNodes}
                edges={displayEdges}
                nodeTypes={nodeTypes}
                onNodesChange={onNodesChange}
                onNodeMouseEnter={onNodeMouseEnter}
                onNodeMouseLeave={onNodeMouseLeave}
                onEdgeMouseEnter={onEdgeMouseEnter}
                onEdgeMouseLeave={onEdgeMouseLeave}
                onNodeContextMenu={onNodeContextMenu}
                onPaneClick={closeContextMenu}
                nodesDraggable
                nodesConnectable={false}
                elevateNodesOnSelect={false}
                fitView
                minZoom={0.01}
                maxZoom={Infinity}
                style={{ width: "100%", height: "100%" }}
            >
                <Background />
                <Controls />
            </ReactFlow>

            {contextMenu && (
                <div
                    style={{ position: "absolute", left: contextMenu.x, top: contextMenu.y, zIndex: 40 }}
                    className="min-w-[200px] py-1 bg-card/95 backdrop-blur border border-border/80 shadow-2xl rounded-lg overflow-hidden select-none"
                    onMouseDown={(e) => e.stopPropagation()}
                    onContextMenu={(e) => e.preventDefault()}
                >
                    <button
                        type="button"
                        onClick={() => {
                            setDependencyTableId(contextMenu.nodeId);
                            setContextMenu(null);
                        }}
                        className="w-full text-left px-3 py-1.5 text-xs text-foreground hover:bg-muted/80 transition-colors"
                    >
                        Display dependency only
                    </button>
                </div>
            )}

            {dependencyTableId && (
                <DependencyPopup tableId={dependencyTableId} onClose={closeDependencyPopup} />
            )}
        </div>
    );
}

export function SchemaViewer() {
    return (
        <ReactFlowProvider>
            <SchemaViewerInner />
        </ReactFlowProvider>
    );
}
