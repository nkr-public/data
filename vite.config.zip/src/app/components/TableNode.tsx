import React, { memo } from "react";
import { Handle, Position } from "reactflow";
import { KeyRound } from "lucide-react";
import type { Column } from "../../lib/cdmTypes";
import { SOURCE_HANDLE_PREFIX, TARGET_HANDLE_PREFIX, type HandleSide } from "../../lib/elkLayout";

export interface TableNodeData {
    table: string;
    columns: Column[];
    /** La table fait partie de la zone du graphe actuellement "allumée". */
    highlighted?: boolean;
    /** Une autre zone du graphe est allumée : la table est atténuée. */
    dimmed?: boolean;
}

const SIDES: { side: HandleSide; position: Position }[] = [
    { side: "top", position: Position.Top },
    { side: "bottom", position: Position.Bottom },
    { side: "left", position: Position.Left },
    { side: "right", position: Position.Right }
];

function TableNodeComponent({ data }: { data: TableNodeData }) {
    const borderClass = data.highlighted
        ? "border-amber-500 ring-2 ring-amber-500/60 shadow-xl"
        : "border-border shadow-md";
    const headerClass = data.highlighted
        ? "bg-amber-500 text-white"
        : "bg-primary text-primary-foreground";
    const handleClass = data.highlighted ? "!bg-amber-500" : "!bg-primary";

    return (
        <div
            className={`min-w-[240px] rounded-lg border bg-surface overflow-hidden text-xs transition-opacity ${borderClass}`}
            style={{ opacity: data.dimmed ? 0.35 : 1 }}
        >
            <div
                data-table-header
                className={`font-bold px-3 py-2 text-sm cursor-move ${headerClass}`}
            >
                {data.table}
            </div>
            <div className="divide-y divide-border/60">
                {data.columns.map((column) => (
                    <div key={column.name} className="flex items-center justify-between gap-2 px-3 py-1.5">
                        <span className="flex items-center gap-1.5 text-foreground">
                            {column.category === "id" && <KeyRound className="w-3 h-3 text-amber-500 shrink-0" />}
                            {column.name}
                        </span>
                        <span className="text-foreground-muted">{column.type}</span>
                    </div>
                ))}
            </div>
            {SIDES.map(({ side, position }) => (
                <React.Fragment key={side}>
                    <Handle
                        id={TARGET_HANDLE_PREFIX + side}
                        type="target"
                        position={position}
                        isConnectable={false}
                        className={handleClass}
                    />
                    <Handle
                        id={SOURCE_HANDLE_PREFIX + side}
                        type="source"
                        position={position}
                        isConnectable={false}
                        className={handleClass}
                    />
                </React.Fragment>
            ))}
        </div>
    );
}

export const TableNode = memo(TableNodeComponent);
