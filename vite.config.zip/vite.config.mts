import {defineConfig} from "vite";
import react from "@vitejs/plugin-react";

const BACKEND_URL = process.env.BACKEND_URL || "http://127.0.0.1:8080";

const host = process.env.TAURI_DEV_HOST;

export default defineConfig(({command}) => ({
    plugins: [react()],
    clearScreen: false,
    define: {
        "process.env.BACKEND_URL": JSON.stringify(BACKEND_URL)
    },
    resolve: {
        alias: {
            "@": "/src"
        }
    },
    server: {
        port: 3010,
        strictPort: true,
        host: host || false,
        watch: {
            ignored: ["**/src-tauri/target/**"]
        },
        proxy: {
            "/api": {
                target: BACKEND_URL,
                changeOrigin: true
            }
        }
    },
    envPrefix: ["VITE_", "TAURI_"],
    build: {
        outDir: "dist",
        target: process.env.TAURI_ENV_PLATFORM === "windows" ? "chrome105" : "es2021",
        minify: !process.env.TAURI_ENV_DEBUG ? "esbuild" : false,
        sourcemap: !!process.env.TAURI_ENV_DEBUG
    }
}));
