package com.cdmviewer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CdmViewerApplication {

    public static void main(String[] args) {
        SpringApplication.run(CdmViewerApplication.class, args);
    }
}
