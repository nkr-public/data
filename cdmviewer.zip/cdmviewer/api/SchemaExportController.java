package com.cdmviewer.api;

import com.cdmviewer.cdm.CdmModel;
import com.cdmviewer.connectors.DbConnectionConfig;
import com.cdmviewer.connectors.MysqlConnector;
import com.cdmviewer.connectors.OracleConnector;
import com.cdmviewer.connectors.SchemaConnector;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.sql.SQLException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Exposes an endpoint able to connect to a MySQL or Oracle database, introspect its schema
 * (tables, columns, primary/foreign keys) and return the resulting CDM model as JSON.
 */
@RestController
public class SchemaExportController {

    /**
     * Cache of previously read schemas, keyed by the (url, schema) pair of the request,
     * to avoid re-introspecting the same database on every call.
     */
    private final Map<CacheKey, CdmModel> schemaCache = new ConcurrentHashMap<>();

    @PostMapping("/api/schema/export")
    public ResponseEntity<CdmModel> exportSchema(@RequestBody SchemaExportRequest request) {
        CacheKey cacheKey = new CacheKey(request.url(), request.schema());
        CdmModel cached = schemaCache.get(cacheKey);
        if (cached != null) {
            return ResponseEntity.ok(cached);
        }

        SchemaConnector connector = resolveConnector(request.type());
        DbConnectionConfig config = new DbConnectionConfig(
                request.url(), request.username(), request.password(), request.schema());

        try {
            CdmModel model = connector.readSchema(config);
            schemaCache.put(cacheKey, model);
            return ResponseEntity.ok(model);
        } catch (SQLException e) {
            throw new IllegalStateException("Unable to read schema: " + e.getMessage(), e);
        }
    }

    private record CacheKey(String url, String schema) {
    }

    private SchemaConnector resolveConnector(String type) {
        if (type == null) {
            throw new IllegalArgumentException("Connector type is required (mysql or oracle)");
        }
        switch (type.toLowerCase()) {
            case "mysql", "mariadb" -> {
                return new MysqlConnector();
            }
            case "oracle" -> {
                return new OracleConnector();
            }
            default -> throw new IllegalArgumentException("Unsupported connector type: " + type);
        }
    }
}
