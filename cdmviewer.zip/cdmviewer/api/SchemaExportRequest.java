package com.cdmviewer.api;

/**
 * Request payload used to introspect a MySQL/Oracle database schema and export it as a CDM model.
 */
public record SchemaExportRequest(String type, String url, String username, String password, String schema) {
}
