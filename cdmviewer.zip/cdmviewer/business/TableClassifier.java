package com.cdmviewer.business;
import java.util.*;
import java.util.stream.Collectors;

public final class TableClassifier {

    public enum Kind {
        BUSINESS,
        REFERENCE_CANDIDATE,
        ASSOCIATION,
        ENRICHED_ASSOCIATION
    }

    public enum Confidence {
        LOW, MEDIUM, HIGH
    }

    public record TableMeta(
        String id,
        Set<String> columns,
        Set<String> primaryKey,
        List<Set<String>> uniqueKeys
    ) {
    }

    // Une instance représente une FK complète,
    // y compris lorsqu'elle porte sur plusieurs colonnes.
    public record ForeignKeyMeta(
        String sourceTable,
        String targetTable,
        Set<String> sourceColumns
    ) {
    }

    public record Classification(
        Kind kind,
        Confidence confidence,
        int incomingTables,
        int outgoingForeignKeys,
        String reason
    ) {
    }

    public static Map<String, Classification> classify(
        List<TableMeta> tables,
        List<ForeignKeyMeta> foreignKeys,
        Set<String> technicalColumns,
        int minimumReferenceConsumers,
        int maximumReferenceBusinessColumns
    ) {
        if (minimumReferenceConsumers < 1
            || maximumReferenceBusinessColumns < 1) {
            throw new IllegalArgumentException("Invalid detection thresholds");
        }

        Set<String> ids = new HashSet<>();
        for (TableMeta table : tables) {
            if (!ids.add(table.id())) {
                throw new IllegalArgumentException(
                    "Duplicate table: " + table.id());
            }
        }

        Map<String, List<ForeignKeyMeta>> outgoing = new HashMap<>();
        Map<String, Set<String>> incoming = new HashMap<>();

        for (ForeignKeyMeta fk : foreignKeys) {
            if (!ids.contains(fk.sourceTable())
                || !ids.contains(fk.targetTable())) {
                throw new IllegalArgumentException(
                    "Unknown FK endpoint: " + fk);
            }
            if (fk.sourceColumns().isEmpty()) {
                throw new IllegalArgumentException("Empty FK: " + fk);
            }

            outgoing.computeIfAbsent(
                fk.sourceTable(), ignored -> new ArrayList<>()
            ).add(fk);

            // Compte les tables consommatrices distinctes.
            if (!fk.sourceTable().equals(fk.targetTable())) {
                incoming.computeIfAbsent(
                    fk.targetTable(), ignored -> new HashSet<>()
                ).add(fk.sourceTable());
            }
        }

        Set<String> technical = technicalColumns.stream()
            .map(name -> name.toLowerCase(Locale.ROOT))
            .collect(Collectors.toSet());

        Map<String, Classification> result = new LinkedHashMap<>();

        for (TableMeta table : tables) {
            List<ForeignKeyMeta> refs =
                outgoing.getOrDefault(table.id(), List.of());

            int consumers =
                incoming.getOrDefault(table.id(), Set.of()).size();

            Set<String> fkColumns = refs.stream()
                .flatMap(fk -> fk.sourceColumns().stream())
                .collect(Collectors.toSet());

            List<Set<String>> keys = new ArrayList<>(table.uniqueKeys());
            if (!table.primaryKey().isEmpty()) {
                keys.add(table.primaryKey());
            }

            // Une clé composée exactement des colonnes de plusieurs FK
            // est un indice fort de table d'association.
            boolean association = refs.size() >= 2
                && refs.stream().map(ForeignKeyMeta::targetTable).distinct().count() >= 2
                && keys.stream().anyMatch(key ->
                !key.isEmpty()
                    && key.equals(fkColumns));

            if (association) {
                Set<String> payload = new HashSet<>(table.columns());
                payload.removeAll(fkColumns);
                payload.removeAll(table.primaryKey());
                payload.removeIf(column -> technical.contains(
                    column.toLowerCase(Locale.ROOT)));

                boolean enriched = !payload.isEmpty();

                result.put(table.id(), new Classification(
                    enriched
                        ? Kind.ENRICHED_ASSOCIATION
                        : Kind.ASSOCIATION,
                    Confidence.HIGH,
                    consumers,
                    refs.size(),
                    enriched
                        ? "FK composant une clé unique, avec attributs supplémentaires"
                        : "FK composant une clé unique, sans attribut métier supplémentaire"
                ));

                continue;
            }

            long businessColumns = table.columns().stream()
                .filter(column -> !technical.contains(
                    column.toLowerCase(Locale.ROOT)))
                .count();

            boolean referenceCandidate =
                refs.isEmpty()
                    && consumers >= minimumReferenceConsumers
                    && businessColumns <= maximumReferenceBusinessColumns;

            result.put(table.id(), new Classification(
                referenceCandidate
                    ? Kind.REFERENCE_CANDIDATE
                    : Kind.BUSINESS,
                referenceCandidate
                    ? Confidence.MEDIUM
                    : Confidence.LOW,
                consumers,
                refs.size(),
                referenceCandidate
                    ? "Table simple, référencée par plusieurs tables, sans FK sortante"
                    : "Classification métier par défaut"
            ));
        }

        return Collections.unmodifiableMap(result);
    }

    private TableClassifier() {
    }
}
