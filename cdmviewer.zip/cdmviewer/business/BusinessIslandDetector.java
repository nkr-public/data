package com.cdmviewer.business;

import com.cdmviewer.cdm.CdmModel;
import com.cdmviewer.cdm.Relation;
import com.cdmviewer.cdm.Table;

import java.util.*;
import java.util.function.*;

public final class BusinessIslandDetector
{

    private BusinessIslandDetector()
    {
    }

    public record Result(List<Set<String>> islands, Set<String> sharedTables)
    {
    }

    public static Result detect(CdmModel model, Function<Table, String> tableId, Function<Relation, String> sourceId,
        Function<Relation, String> targetId, Predicate<Table> isShared, ToDoubleFunction<Relation> relationWeight,
        double resolution)
    {
        if (!Double.isFinite(resolution) || resolution <= 0) {
            throw new IllegalArgumentException("resolution must be finite and > 0");
        }

        Map<String, Integer> indexes = new LinkedHashMap<>();
        Set<String> allIds = new HashSet<>();
        Set<String> shared = new LinkedHashSet<>();

        for (Table table : model.getTables()) {
            String id = Objects.requireNonNull(tableId.apply(table));

            if (!allIds.add(id)) {
                throw new IllegalArgumentException("Duplicate table: " + id);
            }

            if (isShared.test(table)) {
                shared.add(id);
            } else {
                indexes.put(id, indexes.size());
            }
        }

        int n = indexes.size();
        double[][] links = new double[n][n];
        double[] degrees = new double[n];
        double totalWeight = 0;

        for (Relation relation : model.getRelations()) {
            String source = sourceId.apply(relation);
            String target = targetId.apply(relation);

            if (!allIds.contains(source) || !allIds.contains(target)) {
                throw new IllegalArgumentException("Unknown relation endpoint: " + source + " -> " + target);
            }

            double weight = relationWeight.applyAsDouble(relation);
            if (!Double.isFinite(weight) || weight < 0) {
                throw new IllegalArgumentException("Invalid relation weight");
            }

            Integer a = indexes.get(source);
            Integer b = indexes.get(target);

            // Ignore shared tables, self-relations and zero-weight links.
            if (a == null || b == null || a.equals(b) || weight == 0) {
                continue;
            }

            // Undirected graph for clustering.
            links[a][b] += weight;
            links[b][a] += weight;
            degrees[a] += weight;
            degrees[b] += weight;
            totalWeight += weight;
        }

        List<Set<String>> groups = new ArrayList<>();
        for (String id : indexes.keySet()) {
            groups.add(new LinkedHashSet<>(Collections.singleton(id)));
        }

        boolean[] active = new boolean[n];
        Arrays.fill(active, true);

        if (totalWeight > 0) {
            while (true) {
                int bestA = -1;
                int bestB = -1;
                double bestGain = 1e-12;

                for (int a = 0; a < n; a++) {
                    if (!active[a])
                        continue;

                    for (int b = a + 1; b < n; b++) {
                        if (!active[b] || links[a][b] == 0)
                            continue;

                        double gain =
                            links[a][b] / totalWeight - resolution * (degrees[a] / totalWeight) * (degrees[b] / totalWeight) / 2.0;

                        if (gain > bestGain) {
                            bestGain = gain;
                            bestA = a;
                            bestB = b;
                        }
                    }
                }

                if (bestA < 0)
                    break;

                groups.get(bestA).addAll(groups.get(bestB));
                degrees[bestA] += degrees[bestB];

                for (int k = 0; k < n; k++) {
                    if (active[k] && k != bestA && k != bestB) {
                        links[bestA][k] += links[bestB][k];
                        links[k][bestA] = links[bestA][k];
                    }
                }

                active[bestB] = false;
            }
        }

        List<Set<String>> islands = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            if (active[i]) {
                islands.add(Collections.unmodifiableSet(new LinkedHashSet<>(groups.get(i))));
            }
        }

        islands.sort(Comparator.comparingInt((Set<String> group) -> group.size()).reversed());

        return new Result(List.copyOf(islands), Collections.unmodifiableSet(shared));
    }
}
