package com.cdmviewer.cdm;

import java.util.List;

public class Relation {

    private final String id;
    private final String name;
    private final String sourceTable;
    private final String targetTable;
    private final String sourceCardinality;
    private final String targetCardinality;
    private final List<String> sourceColumns;
    private final List<String> targetColumns;

    public Relation(String id, String name, String sourceTable, String targetTable,
                     String sourceCardinality, String targetCardinality) {
        this(id, name, sourceTable, targetTable, sourceCardinality, targetCardinality, List.of(), List.of());
    }

    public Relation(String id, String name, String sourceTable, String targetTable,
                     String sourceCardinality, String targetCardinality,
                     List<String> sourceColumns, List<String> targetColumns) {
        this.id = id;
        this.name = name;
        this.sourceTable = sourceTable;
        this.targetTable = targetTable;
        this.sourceCardinality = sourceCardinality;
        this.targetCardinality = targetCardinality;
        this.sourceColumns = List.copyOf(sourceColumns);
        this.targetColumns = List.copyOf(targetColumns);
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSourceTable() {
        return sourceTable;
    }

    public String getTargetTable() {
        return targetTable;
    }

    public String getSourceCardinality() {
        return sourceCardinality;
    }

    public String getTargetCardinality() {
        return targetCardinality;
    }

    public String getCardinality() {
        return sourceCardinality + ":" + targetCardinality;
    }

    public List<String> getSourceColumns() {
        return sourceColumns;
    }

    public List<String> getTargetColumns() {
        return targetColumns;
    }

    @Override
    public String toString() {
        return "Relation{id='" + id + "', name='" + name + "', sourceTable='" + sourceTable
                + "', targetTable='" + targetTable + "', cardinality='" + getCardinality()
                + "', sourceColumns=" + sourceColumns + ", targetColumns=" + targetColumns + "'}";
    }
}
