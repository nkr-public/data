package com.cdmviewer.cdm;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Set;

@Getter
@Setter
public class CdmModelDto extends CdmModel
{
    public CdmModelDto()
    {
    }

    private List<Set<String>> clusters;

    public CdmModelDto(CdmModel cached, List<Set<String>> sets)
    {
        super();
        clusters = sets;
        tables = cached.getTables();
        relations = cached.getRelations();
    }
}
