package com.cdmviewer.cdm;

import com.cdmviewer.graphml.GraphMlEdge;
import com.cdmviewer.graphml.GraphMlGraph;
import com.cdmviewer.graphml.GraphMlNode;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Converts a generic {@link GraphMlGraph} (produced from a yEd/yFiles UML class diagram)
 * into a {@link CdmModel} made of tables, columns and relations, suitable for JSON export.
 */
public class CdmModelParser {

    private static final List<String> TABLE_NAME_KEYS = List.of("NodeLabel", "className", "label", "name");
    private static final List<String> COLUMN_TEXT_KEYS = List.of("AttributeLabel", "attributes");
    private static final List<String> EDGE_LABEL_KEYS = List.of("EdgeLabel", "label");

    private static final Pattern PK_MARKER = Pattern.compile("^(PK\\d*)\\s+(.+)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern FK_MARKER = Pattern.compile("^(FK\\d*)\\s+(.+)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern INDEX_MARKER = Pattern.compile("^(AK\\d*|UQ\\d*|IDX\\d*)\\s+(.+)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern CARDINALITY = Pattern.compile("^\\s*(.+?)\\s*$");

    public CdmModel parse(GraphMlGraph graph) {
        CdmModel model = new CdmModel();
        Map<String, String> tableIdToName = new LinkedHashMap<>();

        for (GraphMlNode node : graph.getNodes()) {
            Table table = parseTable(node);
            model.addTable(table);
            tableIdToName.put(node.getId(), table.getTable());
        }

        for (GraphMlEdge edge : graph.getEdges()) {
            model.addRelation(parseRelation(edge, tableIdToName));
        }

        return model;
    }

    private Table parseTable(GraphMlNode node) {
        String tableName = resolveTableName(node);
        Table table = new Table(node.getId(), tableName);

        String columnsText = findFirstByKeySuffix(node.getData(), COLUMN_TEXT_KEYS, null);
        if (columnsText != null) {
            addColumnsFromText(table, columnsText);
        }

        return table;
    }

    private void addColumnsFromText(Table table, String text) {
        for (String line : text.split("\\r?\\n")) {
            Column column = parseColumn(line);
            if (column != null) {
                table.addColumn(column);
            }
        }
    }

    private String resolveTableName(GraphMlNode node) {
        String name = findFirstByKeySuffix(node.getData(), TABLE_NAME_KEYS, null);
        return name != null ? firstLine(name) : node.getId();
    }

    private Column parseColumn(String rawLine) {
        String line = rawLine == null ? "" : rawLine.trim();
        if (line.isEmpty()) {
            return null;
        }

        boolean primaryKey = false;
        boolean foreignKey = false;
        boolean indexed = false;
        String remainder = line;

        boolean markerFound = true;
        while (markerFound) {
            markerFound = false;

            Matcher pkMatcher = PK_MARKER.matcher(remainder);
            Matcher fkMatcher = FK_MARKER.matcher(remainder);
            Matcher indexMatcher = INDEX_MARKER.matcher(remainder);

            if (pkMatcher.matches()) {
                primaryKey = true;
                remainder = pkMatcher.group(2).trim();
                markerFound = true;
            } else if (fkMatcher.matches()) {
                foreignKey = true;
                remainder = fkMatcher.group(2).trim();
                markerFound = true;
            } else if (indexMatcher.matches()) {
                indexed = true;
                remainder = indexMatcher.group(2).trim();
                markerFound = true;
            }
        }

        ColumnCategory category = primaryKey ? ColumnCategory.ID
                : foreignKey ? ColumnCategory.EXTERNAL
                : indexed ? ColumnCategory.INDEX
                : ColumnCategory.NONE;

        String name;
        String type;
        int colonIndex = remainder.indexOf(':');
        if (colonIndex >= 0) {
            name = remainder.substring(0, colonIndex).trim();
            type = remainder.substring(colonIndex + 1).trim();
        } else {
            int spaceIndex = remainder.indexOf(' ');
            if (spaceIndex >= 0) {
                name = remainder.substring(0, spaceIndex).trim();
                type = remainder.substring(spaceIndex + 1).trim();
            } else {
                name = remainder;
                type = "";
            }
        }

        if (name.isEmpty()) {
            return null;
        }

        return new Column(name, type, category, foreignKey);
    }

    private Relation parseRelation(GraphMlEdge edge, Map<String, String> tableIdToName) {
        String sourceTable = tableIdToName.getOrDefault(edge.getSource(), edge.getSource());
        String targetTable = tableIdToName.getOrDefault(edge.getTarget(), edge.getTarget());

        String label = findFirstByKeySuffix(edge.getData(), EDGE_LABEL_KEYS, "");
        String[] parts = label.split("\\r?\\n");

        String sourceCardinality = parts.length > 0 ? normalizeCardinality(parts[0]) : "";
        String targetCardinality = parts.length > 1 ? normalizeCardinality(parts[1]) : sourceCardinality;

        return new Relation(edge.getId(), edge.getId(), sourceTable, targetTable, sourceCardinality, targetCardinality);
    }

    private String normalizeCardinality(String value) {
        if (value == null) {
            return "";
        }
        Matcher matcher = CARDINALITY.matcher(value);
        return matcher.matches() ? matcher.group(1) : value.trim();
    }

    private String firstLine(String text) {
        int newlineIndex = text.indexOf('\n');
        return newlineIndex >= 0 ? text.substring(0, newlineIndex).trim() : text.trim();
    }

    private String findByKeySuffix(Map<String, String> data, String suffix) {
        for (Map.Entry<String, String> entry : data.entrySet()) {
            if (entry.getKey().equals(suffix) || entry.getKey().endsWith(":" + suffix)) {
                return entry.getValue();
            }
        }
        return null;
    }

    private String findFirstByKeySuffix(Map<String, String> data, List<String> candidates, String defaultValue) {
        for (String candidate : candidates) {
            String value = findByKeySuffix(data, candidate);
            if (value != null) {
                return value;
            }
        }
        return defaultValue;
    }
}
