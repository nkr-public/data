package com.cdmviewer.cdm;

import java.util.ArrayList;
import java.util.List;

public class CdmModel {

    private final List<Table> tables = new ArrayList<>();
    private final List<Relation> relations = new ArrayList<>();

    public List<Table> getTables() {
        return tables;
    }

    public List<Relation> getRelations() {
        return relations;
    }

    public void addTable(Table table) {
        tables.add(table);
    }

    public void addRelation(Relation relation) {
        relations.add(relation);
    }

    @Override
    public String toString() {
        return "CdmModel{tables=" + tables + ", relations=" + relations + '}';
    }
}
