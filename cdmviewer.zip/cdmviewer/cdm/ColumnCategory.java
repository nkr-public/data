package com.cdmviewer.cdm;

import com.fasterxml.jackson.annotation.JsonValue;

public enum ColumnCategory {
    ID,
    INDEX,
    EXTERNAL,
    NONE;

    @JsonValue
    public String toJson() {
        return name().toLowerCase();
    }
}
