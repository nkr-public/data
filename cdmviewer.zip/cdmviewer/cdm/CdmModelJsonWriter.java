package com.cdmviewer.cdm;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Serializes a {@link CdmModel} into a JSON document describing tables, columns and relations.
 */
public class CdmModelJsonWriter {

    private final ObjectMapper objectMapper;

    public CdmModelJsonWriter() {
        this.objectMapper = new ObjectMapper();
        this.objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
    }

    public String toJson(CdmModel model) throws IOException {
        return objectMapper.writeValueAsString(model);
    }

    public void write(CdmModel model, Path path) throws IOException {
        try (OutputStream outputStream = Files.newOutputStream(path)) {
            write(model, outputStream);
        }
    }

    public void write(CdmModel model, OutputStream outputStream) throws IOException {
        objectMapper.writeValue(outputStream, model);
    }
}
