package com.cdmviewer.cdm;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class Table {

    private final String id;
    private final String table;
    private final List<Column> columns = new ArrayList<>();
    private Set<String> primaryKey;
    private List<Set<String>> uniqueKeys;

    public Table(String id, String table) {
        this.id = id;
        this.table = table;
    }

    public String getId() {
        return id;
    }

    public String getTable() {
        return table;
    }

    public List<Column> getColumns() {
        return columns;
    }

    public void addColumn(Column column) {
        columns.add(column);
    }

    public Set<String> getPrimaryKey() {
        return primaryKey;
    }

    public void setPrimaryKey(Set<String> primaryKey) {
        this.primaryKey = primaryKey;
    }

    public List<Set<String>> getUniqueKeys() {
        return uniqueKeys;
    }

    public void setUniqueKeys(List<Set<String>> uniqueKeys) {
        this.uniqueKeys = uniqueKeys;
    }

    @Override
    public String toString() {
        return "Table{id='" + id + "', table='" + table + "', columns=" + columns
                + ", primaryKey=" + primaryKey + ", uniqueKeys=" + uniqueKeys + '}';
    }
}
