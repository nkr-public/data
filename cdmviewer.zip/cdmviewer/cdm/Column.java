package com.cdmviewer.cdm;

public class Column {

    private final String name;
    private final String type;
    private final ColumnCategory category;
    private final boolean foreignKey;

    public Column(String name, String type, ColumnCategory category) {
        this(name, type, category, category == ColumnCategory.EXTERNAL);
    }

    public Column(String name, String type, ColumnCategory category, boolean foreignKey) {
        this.name = name;
        this.type = type;
        this.category = category;
        this.foreignKey = foreignKey;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public ColumnCategory getCategory() {
        return category;
    }

    public boolean isForeignKey() {
        return foreignKey;
    }

    @Override
    public String toString() {
        return "Column{name='" + name + "', type='" + type + "', category=" + category
                + ", foreignKey=" + foreignKey + '}';
    }
}
