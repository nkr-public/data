package com.cdmviewer.schema;

import com.cdmviewer.business.TableClassifier;

import java.util.Map;
import java.util.Set;

public record MappingOptions(
    MappingMode mode,
    Set<String> technicalColumns,
    int minimumReferenceConsumers,
    int maximumReferenceBusinessColumns,
    double islandResolution,
    double defaultRelationWeight,
    Map<String, Double> relationWeightByCardinality,
    Set<String> sharedTableIds,
    Map<String, TableClassifier.Kind> classificationOverrides,
    Map<String, String> islandNameOverrides
) {

    public static MappingOptions defaults() {
        return new MappingOptions(
            MappingMode.TOLERANT,
            Set.of("id", "created_at", "updated_at", "created_by", "updated_by", "version"),
            2,
            3,
            1.0,
            1.0,
            Map.of(),
            Set.of(),
            Map.of(),
            Map.of()
        );
    }
}
