package com.cdmviewer.schema;

import java.util.List;
import java.util.Set;

public record KeyMetadata(
    Set<String> primaryKey,
    boolean primaryKeyKnown,
    List<Set<String>> uniqueKeys,
    boolean uniqueKeysKnown
) {
}
