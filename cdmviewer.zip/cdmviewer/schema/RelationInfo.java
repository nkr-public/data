package com.cdmviewer.schema;

import java.util.List;

public record RelationInfo(
    String id,
    String name,
    String sourceTableId,
    String targetTableId,
    String sourceCardinality,
    String targetCardinality,
    List<ColumnPair> columnPairs,
    boolean columnMappingKnown,
    boolean selfReference,
    RelationScope scope,
    String sourceIslandId,
    String targetIslandId
) {
}
