package com.cdmviewer.schema;

import java.util.List;

public record IslandDependency(
    String sourceIslandId,
    String targetIslandId,
    int relationCount,
    List<String> relationIds,
    List<String> tableIds
) {
    public IslandDependency(String sourceIslandId, String targetIslandId, int relationCount, List<String> relationIds) {
        this(sourceIslandId, targetIslandId, relationCount, relationIds, List.of());
    }
}
