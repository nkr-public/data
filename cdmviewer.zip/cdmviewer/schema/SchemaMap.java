package com.cdmviewer.schema;

import java.util.List;

public record SchemaMap(
    List<TableInfo> tables,
    List<RelationInfo> relations,
    List<Island> islands,
    List<String> sharedTableIds,
    List<IslandDependency> islandDependencies,
    SchemaStats stats,
    List<Diagnostic> diagnostics
) {
}
