package com.cdmviewer.schema;

import java.util.Map;
import java.util.Set;

public record SchemaStats(
    int tableCount,
    int relationCount,
    int islandCount,
    int sharedTableCount,
    int isolatedIslandCount,
    int largestIslandSize,
    Map<String, Set<String>> tableCountByKind,
    Map<String, Integer> relationCountByScope
) {
}
