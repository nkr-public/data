package com.cdmviewer.schema;

import java.util.*;
import java.util.stream.Collectors;

public record Island(String id, String proposedName, boolean nameOverridden, List<String> tableIds,
                     Map<String, Set<RelationInfo>> dependsOn)
{
    public Island(String id, String proposedName, boolean nameOverridden, List<String> tableIds)
    {
        this(id, proposedName, nameOverridden, tableIds, Map.of());
    }

    public List<String> getAllTable()
    {
        Set<String> result = new HashSet<>(tableIds);
        result.addAll(tableIds);
        Set<String> rr = dependsOn.values().stream().flatMap(Collection::stream).map(relationInfo -> {
            ArrayList<String> r = new ArrayList<>();
            r.add(relationInfo.sourceTableId());
            r.add(relationInfo.targetTableId());
            return r;
        }).flatMap(List::stream).collect(Collectors.toSet());
        result.addAll(rr);
        return result.stream().toList();
    }
}
