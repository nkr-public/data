package com.cdmviewer.schema;

public enum RelationScope {
    INTRA_ISLAND,
    INTER_ISLAND,
    DOMAIN_TO_SHARED,
    SHARED_TO_SHARED,
    UNRESOLVED
}
