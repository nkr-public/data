package com.cdmviewer.schema;

public record ColumnPair(
    String sourceColumn,
    String targetColumn
) {
}
