package com.cdmviewer.schema;

import com.cdmviewer.cdm.ColumnCategory;

public record ColumnInfo(
    String name,
    String type,
    ColumnCategory category,
    boolean foreignKey
) {
}
