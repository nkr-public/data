package com.cdmviewer.schema;

import com.cdmviewer.business.TableClassifier;

public record TableClassificationInfo(
    TableClassifier.Kind kind,
    TableClassifier.Confidence confidence,
    String reason,
    int incomingTables,
    int outgoingForeignKeys,
    boolean overridden,
    TableClassifier.Kind automaticKind
) {
}
