package com.cdmviewer.schema;

public record Diagnostic(
    DiagnosticSeverity severity,
    String code,
    String message,
    String relatedTableId,
    String relatedRelationId
) {
}
