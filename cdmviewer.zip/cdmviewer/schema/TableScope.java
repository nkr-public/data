package com.cdmviewer.schema;

public enum TableScope {
    DOMAIN,
    SHARED
}
