package com.cdmviewer.schema;

import java.util.List;

public record TableInfo(
    String id,
    String name,
    List<ColumnInfo> columns,
    KeyMetadata keys,
    TableClassificationInfo classification,
    TableScope scope,
    String islandId
) {
}
