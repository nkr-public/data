package com.cdmviewer.schema;

import com.cdmviewer.business.BusinessIslandDetector;
import com.cdmviewer.business.TableClassifier;
import com.cdmviewer.cdm.CdmModel;
import com.cdmviewer.cdm.Column;
import com.cdmviewer.cdm.ColumnCategory;
import com.cdmviewer.cdm.Relation;
import com.cdmviewer.cdm.Table;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

@Service
public final class SchemaMappingService {

    public SchemaMap map(CdmModel model, MappingOptions options) {
        if (model == null) {
            throw new IllegalArgumentException("model must not be null");
        }
        if (options == null) {
            throw new IllegalArgumentException("options must not be null");
        }

        List<Diagnostic> diagnostics = new ArrayList<>();

        List<Table> tables = new ArrayList<>(model.getTables());
        tables.sort(Comparator.comparing(Table::getId));

        Map<String, Table> tableById = new LinkedHashMap<>();
        for (Table table : tables) {
            if (tableById.put(table.getId(), table) != null) {
                throw new IllegalArgumentException("Duplicate table id: " + table.getId());
            }
        }

        Map<String, List<String>> tableIdsByName = new LinkedHashMap<>();
        for (Table table : tables) {
            tableIdsByName.computeIfAbsent(table.getTable(), ignored -> new ArrayList<>()).add(table.getId());
        }

        List<Relation> relations = new ArrayList<>(model.getRelations());
        relations.sort(Comparator.comparing(Relation::getId));

        Map<String, String> resolvedSourceId = new LinkedHashMap<>();
        Map<String, String> resolvedTargetId = new LinkedHashMap<>();

        for (Relation relation : relations) {
            String sourceId = resolveTableReference(relation.getSourceTable(), tableById, tableIdsByName,
                relation.getId(), diagnostics);
            String targetId = resolveTableReference(relation.getTargetTable(), tableById, tableIdsByName,
                relation.getId(), diagnostics);

            if (sourceId == null || targetId == null) {
                if (options.mode() == MappingMode.STRICT) {
                    throw new IllegalArgumentException(
                        "Unresolved relation endpoint for relation " + relation.getId());
                }
                diagnostics.add(new Diagnostic(DiagnosticSeverity.WARNING, "relation_unresolved_endpoint",
                    "La relation " + relation.getId() + " reference une table introuvable ("
                        + relation.getSourceTable() + " -> " + relation.getTargetTable() + ")",
                    null, relation.getId()));
            } else {
                resolvedSourceId.put(relation.getId(), sourceId);
                resolvedTargetId.put(relation.getId(), targetId);
            }
        }

        Set<String> sharedTableIds = new LinkedHashSet<>();
        for (String candidate : options.sharedTableIds()) {
            if (tableById.containsKey(candidate)) {
                sharedTableIds.add(candidate);
            } else {
                diagnostics.add(new Diagnostic(DiagnosticSeverity.WARNING, "shared_table_unknown",
                    "La table partagee declaree '" + candidate + "' est introuvable dans le modele",
                    candidate, null));
            }
        }

        Map<String, KeyMetadata> keyMetadataByTableId = new LinkedHashMap<>();
        List<TableClassifier.TableMeta> tableMetas = new ArrayList<>();
        for (Table table : tables) {
            KeyMetadata keyMetadata = buildKeyMetadata(table, diagnostics);
            keyMetadataByTableId.put(table.getId(), keyMetadata);
            tableMetas.add(new TableClassifier.TableMeta(table.getId(), columnNames(table),
                keyMetadata.primaryKey(), keyMetadata.uniqueKeys()));
        }

        Map<String, List<ColumnPair>> columnPairsByRelationId = new LinkedHashMap<>();
        Map<String, Boolean> columnMappingKnownByRelationId = new LinkedHashMap<>();
        List<TableClassifier.ForeignKeyMeta> foreignKeyMetas = new ArrayList<>();

        for (Relation relation : relations) {
            String sourceId = resolvedSourceId.get(relation.getId());
            String targetId = resolvedTargetId.get(relation.getId());
            if (sourceId == null || targetId == null) {
                continue;
            }

            List<ColumnPair> columnPairs = buildColumnPairs(relation);
            columnPairsByRelationId.put(relation.getId(), columnPairs);

            Set<String> sourceColumns;
            boolean known;
            if (!columnPairs.isEmpty()) {
                sourceColumns = new LinkedHashSet<>();
                for (ColumnPair pair : columnPairs) {
                    sourceColumns.add(pair.sourceColumn());
                }
                known = true;
            } else {
                Set<String> approximated = foreignKeyFlaggedColumns(tableById.get(sourceId));
                if (!approximated.isEmpty()) {
                    sourceColumns = approximated;
                    known = false;
                    diagnostics.add(new Diagnostic(DiagnosticSeverity.INFO, "foreign_key_columns_approximated",
                        "Les colonnes de la cle etrangere de la relation " + relation.getId()
                            + " sont approximees a partir des colonnes marquees FK de la table source",
                        sourceId, relation.getId()));
                } else {
                    sourceColumns = Set.of("__relation__" + relation.getId());
                    known = false;
                    diagnostics.add(new Diagnostic(DiagnosticSeverity.WARNING, "foreign_key_columns_unknown",
                        "Les colonnes de la cle etrangere de la relation " + relation.getId()
                            + " sont inconnues, une colonne synthetique est utilisee pour la classification",
                        sourceId, relation.getId()));
                }
            }

            columnMappingKnownByRelationId.put(relation.getId(), known);
            foreignKeyMetas.add(new TableClassifier.ForeignKeyMeta(sourceId, targetId, sourceColumns));
        }

        Map<String, TableClassifier.Classification> automaticClassifications = TableClassifier.classify(
            tableMetas, foreignKeyMetas, options.technicalColumns(),
            options.minimumReferenceConsumers(), options.maximumReferenceBusinessColumns());

        for (String overriddenId : options.classificationOverrides().keySet()) {
            if (!tableById.containsKey(overriddenId)) {
                diagnostics.add(new Diagnostic(DiagnosticSeverity.WARNING, "classification_override_unknown_table",
                    "La classification manuelle pour '" + overriddenId + "' ne correspond a aucune table",
                    overriddenId, null));
            }
        }

        Map<String, TableClassificationInfo> classificationByTableId = new LinkedHashMap<>();
        for (Table table : tables) {
            TableClassifier.Classification automatic = automaticClassifications.get(table.getId());
            TableClassifier.Kind override = options.classificationOverrides().get(table.getId());

            if (override != null) {
                classificationByTableId.put(table.getId(), new TableClassificationInfo(
                    override, TableClassifier.Confidence.HIGH, "Classification manuelle",
                    automatic.incomingTables(), automatic.outgoingForeignKeys(), true, automatic.kind()));
            } else {
                classificationByTableId.put(table.getId(), new TableClassificationInfo(
                    automatic.kind(), automatic.confidence(), automatic.reason(),
                    automatic.incomingTables(), automatic.outgoingForeignKeys(), false, automatic.kind()));
            }
        }

        CdmModel islandModel = new CdmModel();
        for (Table table : tables) {
            islandModel.addTable(table);
        }
        for (Relation relation : relations) {
            if (resolvedSourceId.containsKey(relation.getId())) {
                islandModel.addRelation(relation);
            }
        }

        BusinessIslandDetector.Result islandResult = BusinessIslandDetector.detect(
            islandModel,
            Table::getId,
            relation -> resolvedSourceId.get(relation.getId()),
            relation -> resolvedTargetId.get(relation.getId()),
            table -> sharedTableIds.contains(table.getId()),
            relation -> resolveWeight(relation, options),
            options.islandResolution());

        Map<String, String> islandIdByTableId = new LinkedHashMap<>();
        Map<String, IslandMetadata> islandMetaById = new LinkedHashMap<>();
        for (Set<String> members : islandResult.islands()) {
            List<String> sortedMembers = new ArrayList<>(members);
            sortedMembers.sort(Comparator.naturalOrder());

            String islandId = stableIslandId(sortedMembers);
            for (String memberId : sortedMembers) {
                islandIdByTableId.put(memberId, islandId);
            }

            String overrideName = options.islandNameOverrides().get(islandId);
            String proposedName = overrideName != null
                ? overrideName
                : proposeIslandName(sortedMembers, tableById, classificationByTableId);

            islandMetaById.put(islandId, new IslandMetadata(islandId, proposedName, overrideName != null, sortedMembers));
        }

        List<TableInfo> tableInfos = new ArrayList<>();
        for (Table table : tables) {
            boolean shared = sharedTableIds.contains(table.getId());
            tableInfos.add(new TableInfo(
                table.getId(),
                table.getTable(),
                buildColumnInfos(table),
                keyMetadataByTableId.get(table.getId()),
                classificationByTableId.get(table.getId()),
                shared ? TableScope.SHARED : TableScope.DOMAIN,
                shared ? null : islandIdByTableId.get(table.getId())));
        }

        List<RelationInfo> relationInfos = new ArrayList<>();
        Map<String, Map<String, List<String>>> islandDependencyRelationIds = new TreeMap<>();
        Map<String, Map<String, Set<String>>> islandDependencyTableIds = new TreeMap<>();
        Map<String, Map<String, Set<RelationInfo>>> islandDependsOn = new TreeMap<>();

        for (Relation relation : relations) {
            String sourceId = resolvedSourceId.get(relation.getId());
            String targetId = resolvedTargetId.get(relation.getId());

            if (sourceId == null || targetId == null) {
                relationInfos.add(new RelationInfo(relation.getId(), relation.getName(),
                    relation.getSourceTable(), relation.getTargetTable(),
                    relation.getSourceCardinality(), relation.getTargetCardinality(),
                    List.of(), false, false, RelationScope.UNRESOLVED, null, null));
                continue;
            }

            boolean selfReference = sourceId.equals(targetId);
            boolean sourceShared = sharedTableIds.contains(sourceId);
            boolean targetShared = sharedTableIds.contains(targetId);
            String sourceIslandId = sourceShared ? null : islandIdByTableId.get(sourceId);
            String targetIslandId = targetShared ? null : islandIdByTableId.get(targetId);

            RelationScope scope;
            if (sourceShared && targetShared) {
                scope = RelationScope.SHARED_TO_SHARED;
            } else if (sourceShared || targetShared) {
                scope = RelationScope.DOMAIN_TO_SHARED;
            } else if (sourceIslandId.equals(targetIslandId)) {
                scope = RelationScope.INTRA_ISLAND;
            } else {
                scope = RelationScope.INTER_ISLAND;
                islandDependencyRelationIds
                    .computeIfAbsent(sourceIslandId, ignored -> new TreeMap<>())
                    .computeIfAbsent(targetIslandId, ignored -> new ArrayList<>())
                    .add(relation.getId());
                islandDependencyTableIds
                    .computeIfAbsent(sourceIslandId, ignored -> new TreeMap<>())
                    .computeIfAbsent(targetIslandId, ignored -> new TreeSet<>())
                    .addAll(List.of(sourceId, targetId));
            }

            RelationInfo relationInfo = new RelationInfo(relation.getId(), relation.getName(),
                sourceId, targetId, relation.getSourceCardinality(), relation.getTargetCardinality(),
                columnPairsByRelationId.getOrDefault(relation.getId(), List.of()),
                columnMappingKnownByRelationId.getOrDefault(relation.getId(), false),
                selfReference, scope, sourceIslandId, targetIslandId);
            relationInfos.add(relationInfo);

            if (scope == RelationScope.INTER_ISLAND) {
                islandDependsOn
                    .computeIfAbsent(sourceIslandId, ignored -> new TreeMap<>())
                    .computeIfAbsent(targetIslandId, ignored -> new LinkedHashSet<>())
                    .add(relationInfo);
            }
        }

        List<IslandDependency> islandDependencies = new ArrayList<>();
        for (Map.Entry<String, Map<String, List<String>>> sourceEntry : islandDependencyRelationIds.entrySet()) {
            String sourceIsland = sourceEntry.getKey();
            for (Map.Entry<String, List<String>> targetEntry : sourceEntry.getValue().entrySet()) {
                String targetIsland = targetEntry.getKey();
                Set<String> relatedTables = islandDependencyTableIds
                    .getOrDefault(sourceIsland, Map.of())
                    .getOrDefault(targetIsland, Set.of());
                List<String> sortedTableIds = new ArrayList<>(relatedTables);
                sortedTableIds.sort(Comparator.naturalOrder());
                islandDependencies.add(new IslandDependency(sourceIsland, targetIsland,
                    targetEntry.getValue().size(), List.copyOf(targetEntry.getValue()), List.copyOf(sortedTableIds)));
            }
        }

        List<Island> islands = new ArrayList<>();
        for (IslandMetadata meta : islandMetaById.values()) {
            Map<String, Set<RelationInfo>> dependsOn = new TreeMap<>();
            Map<String, Set<RelationInfo>> rawDependsOn = islandDependsOn.get(meta.id());
            if (rawDependsOn != null) {
                for (Map.Entry<String, Set<RelationInfo>> entry : rawDependsOn.entrySet()) {
                    dependsOn.put(entry.getKey(), Collections.unmodifiableSet(new LinkedHashSet<>(entry.getValue())));
                }
            }
            islands.add(new Island(meta.id(), meta.proposedName(), meta.nameOverridden(), meta.tableIds(),
                Collections.unmodifiableMap(dependsOn)));
        }
        islands.sort(Comparator.comparing(Island::id));

        SchemaStats stats = buildStats(tableInfos, relationInfos, islands, sharedTableIds);

        List<String> sortedSharedIds = new ArrayList<>(sharedTableIds);
        sortedSharedIds.sort(Comparator.naturalOrder());

        return new SchemaMap(tableInfos, relationInfos, islands, sortedSharedIds, islandDependencies, stats,
            diagnostics);
    }

    private String resolveTableReference(String reference, Map<String, Table> tableById,
            Map<String, List<String>> tableIdsByName, String relationId, List<Diagnostic> diagnostics) {
        if (reference == null) {
            return null;
        }
        if (tableById.containsKey(reference)) {
            return reference;
        }
        List<String> candidates = tableIdsByName.get(reference);
        if (candidates == null || candidates.isEmpty()) {
            return null;
        }
        if (candidates.size() > 1) {
            diagnostics.add(new Diagnostic(DiagnosticSeverity.WARNING, "relation_endpoint_ambiguous_name",
                "La reference '" + reference + "' de la relation " + relationId
                    + " correspond a plusieurs tables portant le meme nom",
                null, relationId));
            return null;
        }
        return candidates.get(0);
    }

    private Set<String> columnNames(Table table) {
        Set<String> names = new LinkedHashSet<>();
        for (Column column : table.getColumns()) {
            names.add(column.getName());
        }
        return names;
    }

    private Set<String> foreignKeyFlaggedColumns(Table table) {
        if (table == null) {
            return Set.of();
        }
        Set<String> names = new LinkedHashSet<>();
        for (Column column : table.getColumns()) {
            if (column.isForeignKey()) {
                names.add(column.getName());
            }
        }
        return names;
    }

    private KeyMetadata buildKeyMetadata(Table table, List<Diagnostic> diagnostics) {
        boolean primaryKeyKnown = table.getPrimaryKey() != null;
        Set<String> primaryKey;
        if (primaryKeyKnown) {
            primaryKey = Set.copyOf(table.getPrimaryKey());
        } else {
            primaryKey = new LinkedHashSet<>();
            for (Column column : table.getColumns()) {
                if (column.getCategory() == ColumnCategory.ID) {
                    primaryKey.add(column.getName());
                }
            }
            diagnostics.add(new Diagnostic(DiagnosticSeverity.INFO, "primary_key_metadata_unavailable",
                "Aucune metadonnee de cle primaire certifiee n'est disponible pour la table "
                    + table.getId() + ", une deduction est faite a partir des colonnes marquees",
                table.getId(), null));
        }

        boolean uniqueKeysKnown = table.getUniqueKeys() != null;
        List<Set<String>> uniqueKeys;
        if (uniqueKeysKnown) {
            List<Set<String>> copy = new ArrayList<>();
            for (Set<String> key : table.getUniqueKeys()) {
                copy.add(Set.copyOf(key));
            }
            uniqueKeys = List.copyOf(copy);
        } else {
            Set<String> indexed = new LinkedHashSet<>();
            for (Column column : table.getColumns()) {
                if (column.getCategory() == ColumnCategory.INDEX) {
                    indexed.add(column.getName());
                }
            }
            uniqueKeys = indexed.isEmpty() ? List.of() : List.of(Set.copyOf(indexed));
            diagnostics.add(new Diagnostic(DiagnosticSeverity.INFO, "unique_key_metadata_unavailable",
                "Aucune metadonnee de contrainte unique certifiee n'est disponible pour la table "
                    + table.getId() + ", un regroupement heuristique est utilise a la place",
                table.getId(), null));
        }

        return new KeyMetadata(Set.copyOf(primaryKey), primaryKeyKnown, uniqueKeys, uniqueKeysKnown);
    }

    private List<ColumnPair> buildColumnPairs(Relation relation) {
        List<String> sourceColumns = relation.getSourceColumns();
        List<String> targetColumns = relation.getTargetColumns();
        if (sourceColumns.isEmpty() || sourceColumns.size() != targetColumns.size()) {
            return List.of();
        }
        List<ColumnPair> pairs = new ArrayList<>();
        for (int i = 0; i < sourceColumns.size(); i++) {
            pairs.add(new ColumnPair(sourceColumns.get(i), targetColumns.get(i)));
        }
        return List.copyOf(pairs);
    }

    private List<ColumnInfo> buildColumnInfos(Table table) {
        List<ColumnInfo> columns = new ArrayList<>();
        for (Column column : table.getColumns()) {
            columns.add(new ColumnInfo(column.getName(), column.getType(), column.getCategory(),
                column.isForeignKey()));
        }
        return List.copyOf(columns);
    }

    private double resolveWeight(Relation relation, MappingOptions options) {
        Double specific = options.relationWeightByCardinality().get(relation.getCardinality());
        return specific != null ? specific : options.defaultRelationWeight();
    }

    private String proposeIslandName(List<String> memberIds, Map<String, Table> tableById,
            Map<String, TableClassificationInfo> classificationByTableId) {
        List<String> businessNames = new ArrayList<>();
        for (String memberId : memberIds) {
            TableClassificationInfo classification = classificationByTableId.get(memberId);
            if (classification != null && classification.kind() == TableClassifier.Kind.BUSINESS) {
                businessNames.add(tableById.get(memberId).getTable());
            }
        }
        businessNames.sort(Comparator.naturalOrder());

        if (businessNames.isEmpty()) {
            return "Ilot non identifie";
        }
        if (businessNames.size() == 1) {
            return businessNames.get(0);
        }
        return businessNames.get(0) + " & " + businessNames.get(1);
    }

    private String stableIslandId(List<String> sortedMemberIds) {
        String joined = String.join("|", sortedMemberIds);
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(joined.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (int i = 0; i < 8; i++) {
                hex.append(String.format("%02x", hash[i]));
            }
            return "island-" + hex;
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 unavailable", e);
        }
    }

    private SchemaStats buildStats(List<TableInfo> tableInfos, List<RelationInfo> relationInfos,
            List<Island> islands, Set<String> sharedTableIds) {
        Map<String, Set<String>> tableCountByKind = new TreeMap<>();
        for (TableInfo tableInfo : tableInfos) {
            tableCountByKind
                .computeIfAbsent(tableInfo.classification().kind().name(), ignored -> new TreeSet<>())
                .add(tableInfo.id());
        }

        Map<String, Integer> relationCountByScope = new TreeMap<>();
        for (RelationInfo relationInfo : relationInfos) {
            relationCountByScope.merge(relationInfo.scope().name(), 1, Integer::sum);
        }

        int isolatedIslandCount = 0;
        int largestIslandSize = 0;
        for (Island island : islands) {
            int size = island.tableIds().size();
            if (size == 1) {
                isolatedIslandCount++;
            }
            largestIslandSize = Math.max(largestIslandSize, size);
        }

        Map<String, Set<String>> unmodifiableTableCountByKind = new TreeMap<>();
        for (Map.Entry<String, Set<String>> entry : tableCountByKind.entrySet()) {
            unmodifiableTableCountByKind.put(entry.getKey(), Collections.unmodifiableSet(entry.getValue()));
        }

        return new SchemaStats(tableInfos.size(), relationInfos.size(), islands.size(), sharedTableIds.size(),
            isolatedIslandCount, largestIslandSize, Collections.unmodifiableMap(unmodifiableTableCountByKind),
            Collections.unmodifiableMap(relationCountByScope));
    }

    private record IslandMetadata(
        String id,
        String proposedName,
        boolean nameOverridden,
        List<String> tableIds
    ) {
    }
}
