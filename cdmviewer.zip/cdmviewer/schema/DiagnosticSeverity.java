package com.cdmviewer.schema;

public enum DiagnosticSeverity {
    INFO,
    WARNING,
    ERROR
}
