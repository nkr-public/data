package com.cdmviewer.schema;

public enum MappingMode {
    STRICT,
    TOLERANT
}
