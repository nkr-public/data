package com.cdmviewer.schema;

import com.cdmviewer.cdm.CdmModel;
import com.cdmviewer.cdm.Column;
import com.cdmviewer.cdm.ColumnCategory;
import com.cdmviewer.cdm.Relation;
import com.cdmviewer.cdm.Table;
import com.cdmviewer.connectors.DbConnectionConfig;
import com.cdmviewer.connectors.MysqlConnector;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.util.List;
import java.util.Set;

public final class SchemaMappingExample {

    public static void main(String[] args) throws Exception {
        CdmModel model = new MysqlConnector().readSchema(
            new DbConnectionConfig("jdbc:mysql://localhost:3306/", "root", "root", "car2"));

        MappingOptions options = new MappingOptions(
            MappingMode.TOLERANT,
            Set.of("created_at", "updated_at"),
            1,
            100,
            1.0,
            1.0,
            java.util.Map.of(),
            Set.of("STATUS"),
            java.util.Map.of(),
            java.util.Map.of());

        SchemaMap schemaMap = new SchemaMappingService().map(model, options);

        ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
        System.out.println(mapper.writeValueAsString(schemaMap));

        demonstrateTolerantModeWithMissingMetadata();
        demonstrateStrictModeRejection();
    }

    private static void demonstrateTolerantModeWithMissingMetadata() {
        CdmModel model = new CdmModel();
        Table product = new Table("PRODUCT", "PRODUCT");
        product.addColumn(new Column("id", "int", ColumnCategory.ID));
        product.addColumn(new Column("category_id", "int", ColumnCategory.EXTERNAL));
        model.addTable(product);

        model.addRelation(new Relation("REL_PRODUCT_UNKNOWN", "REL_PRODUCT_UNKNOWN", "PRODUCT", "MISSING_CATEGORY",
            "n", "1"));

        SchemaMap schemaMap = new SchemaMappingService().map(model, MappingOptions.defaults());

        System.out.println("--- Mode tolerant, metadonnees manquantes et relation non resolue ---");
        for (Diagnostic diagnostic : schemaMap.diagnostics()) {
            System.out.println(diagnostic.severity() + " [" + diagnostic.code() + "] " + diagnostic.message());
        }
    }

    private static void demonstrateStrictModeRejection() {
        CdmModel model = new CdmModel();
        Table product = new Table("PRODUCT", "PRODUCT");
        model.addTable(product);
        model.addRelation(new Relation("REL_PRODUCT_UNKNOWN", "REL_PRODUCT_UNKNOWN", "PRODUCT", "MISSING_CATEGORY",
            "n", "1"));

        MappingOptions strictOptions = new MappingOptions(MappingMode.STRICT, Set.of(), 2, 3, 1.0, 1.0,
            java.util.Map.of(), Set.of(), java.util.Map.of(), java.util.Map.of());

        System.out.println("--- Mode strict, relation non resolue ---");
        try {
            new SchemaMappingService().map(model, strictOptions);
            System.out.println("Aucune exception levee (inattendu)");
        } catch (IllegalArgumentException e) {
            System.out.println("Rejet attendu : " + e.getMessage());
        }
    }

    private static CdmModel buildSampleModel() {
        CdmModel model = new CdmModel();

        Table user = new Table("USER", "USER");
        user.addColumn(new Column("id", "int", ColumnCategory.ID));
        user.addColumn(new Column("email", "varchar", ColumnCategory.NONE));
        user.addColumn(new Column("status_id", "int", ColumnCategory.EXTERNAL));
        user.setPrimaryKey(Set.of("id"));
        user.setUniqueKeys(List.of(Set.of("email")));
        model.addTable(user);

        Table role = new Table("ROLE", "ROLE");
        role.addColumn(new Column("id", "int", ColumnCategory.ID));
        role.addColumn(new Column("label", "varchar", ColumnCategory.NONE));
        role.setPrimaryKey(Set.of("id"));
        role.setUniqueKeys(List.of());
        model.addTable(role);

        Table userRole = new Table("USER_ROLE", "USER_ROLE");
        userRole.addColumn(new Column("user_id", "int", ColumnCategory.ID, true));
        userRole.addColumn(new Column("role_id", "int", ColumnCategory.ID, true));
        userRole.setPrimaryKey(Set.of("user_id", "role_id"));
        userRole.setUniqueKeys(List.of());
        model.addTable(userRole);

        Table order = new Table("ORDER_TBL", "ORDER_TBL");
        order.addColumn(new Column("id", "int", ColumnCategory.ID));
        order.addColumn(new Column("user_id", "int", ColumnCategory.EXTERNAL));
        order.addColumn(new Column("status_id", "int", ColumnCategory.EXTERNAL));
        order.addColumn(new Column("amount", "decimal", ColumnCategory.NONE));
        order.setPrimaryKey(Set.of("id"));
        order.setUniqueKeys(List.of());
        model.addTable(order);

        Table status = new Table("STATUS", "STATUS");
        status.addColumn(new Column("id", "int", ColumnCategory.ID));
        status.addColumn(new Column("label", "varchar", ColumnCategory.NONE));
        status.setPrimaryKey(Set.of("id"));
        status.setUniqueKeys(List.of());
        model.addTable(status);

        model.addRelation(new Relation("REL_USER_ROLE_USER", "REL_USER_ROLE_USER", "USER_ROLE", "USER", "n", "1",
            List.of("user_id"), List.of("id")));
        model.addRelation(new Relation("REL_USER_ROLE_ROLE", "REL_USER_ROLE_ROLE", "USER_ROLE", "ROLE", "n", "1",
            List.of("role_id"), List.of("id")));
        model.addRelation(new Relation("REL_USER_STATUS", "REL_USER_STATUS", "USER", "STATUS", "n", "1",
            List.of("status_id"), List.of("id")));
        model.addRelation(new Relation("REL_ORDER_STATUS", "REL_ORDER_STATUS", "ORDER_TBL", "STATUS", "n", "1",
            List.of("status_id"), List.of("id")));
        model.addRelation(new Relation("REL_ORDER_USER", "REL_ORDER_USER", "ORDER_TBL", "USER", "n", "1",
            List.of("user_id"), List.of("id")));

        return model;
    }
}
