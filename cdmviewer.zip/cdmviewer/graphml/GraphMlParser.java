package com.cdmviewer.graphml;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Parser for GraphML files, with basic support for yFiles UML class nodes
 * (y:UMLClassNode / y:NodeLabel / y:UML / y:AttributeLabel) and yEd UML class
 * models (uml:UMLClassModel with attributes/operations arrays).
 */
public class GraphMlParser {

    public GraphMlGraph parse(File file) {
        try (InputStream inputStream = Files.newInputStream(file.toPath())) {
            return parse(inputStream);
        } catch (IOException e) {
            throw new GraphMlParseException("Unable to read GraphML file: " + file, e);
        }
    }

    public GraphMlGraph parse(Path path) {
        try (InputStream inputStream = Files.newInputStream(path)) {
            return parse(inputStream);
        } catch (IOException e) {
            throw new GraphMlParseException("Unable to read GraphML file: " + path, e);
        }
    }

    public GraphMlGraph parse(InputStream inputStream) {
        try {
            String content = new String(inputStream.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
            content = content.stripLeading();

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new java.io.ByteArrayInputStream(content.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
            return parseDocument(document);
        } catch (ParserConfigurationException | SAXException | IOException e) {
            throw new GraphMlParseException("Unable to parse GraphML document", e);
        }
    }

    private GraphMlGraph parseDocument(Document document) {
        Element root = document.getDocumentElement();
        if (root == null || !"graphml".equals(root.getLocalName())) {
            throw new GraphMlParseException("Invalid GraphML document: missing root 'graphml' element");
        }

        Map<String, String> keys = parseKeys(root);

        Element graphElement = getFirstChildElement(root, "graph");
        if (graphElement == null) {
            throw new GraphMlParseException("Invalid GraphML document: missing 'graph' element");
        }

        return parseGraph(graphElement, keys);
    }

    private Map<String, String> parseKeys(Element root) {
        Map<String, String> keys = new LinkedHashMap<>();
        NodeList children = root.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node node = children.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE && "key".equals(((Element) node).getLocalName())) {
                Element keyElement = (Element) node;
                String id = keyElement.getAttribute("id");
                String attrName = keyElement.getAttribute("attr.name");
                if (id != null && !attrName.isEmpty()) {
                    keys.put(id, attrName);
                }
            }
        }
        return keys;
    }

    private GraphMlGraph parseGraph(Element graphElement, Map<String, String> keys) {
        String id = graphElement.getAttribute("id");
        String edgeDefault = graphElement.getAttribute("edgedefault");
        GraphMlGraph graph = new GraphMlGraph(id, edgeDefault);

        NodeList children = graphElement.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node node = children.item(i);
            if (node.getNodeType() != Node.ELEMENT_NODE) {
                continue;
            }
            Element element = (Element) node;
            String localName = element.getLocalName();
            if ("node".equals(localName)) {
                graph.addNode(parseNode(element, keys));
            } else if ("edge".equals(localName)) {
                graph.addEdge(parseEdge(element, keys));
            }
        }

        return graph;
    }

    private GraphMlNode parseNode(Element element, Map<String, String> keys) {
        GraphMlNode node = new GraphMlNode(element.getAttribute("id"));
        populateData(element, keys, node::putData);
        return node;
    }

    private GraphMlEdge parseEdge(Element element, Map<String, String> keys) {
        GraphMlEdge edge = new GraphMlEdge(
                element.getAttribute("id"),
                element.getAttribute("source"),
                element.getAttribute("target"));
        populateData(element, keys, edge::putData);
        return edge;
    }

    private void populateData(Element ownerElement, Map<String, String> keys, DataConsumer consumer) {
        NodeList children = ownerElement.getChildNodes();
        Map<String, StringBuilder> structuredData = new LinkedHashMap<>();
        for (int i = 0; i < children.getLength(); i++) {
            Node node = children.item(i);
            if (node.getNodeType() != Node.ELEMENT_NODE || !"data".equals(((Element) node).getLocalName())) {
                continue;
            }
            Element dataElement = (Element) node;
            String keyId = dataElement.getAttribute("key");
            String attrName = keys.get(keyId);

            boolean hasChildElement = false;
            NodeList dataChildren = dataElement.getChildNodes();
            for (int j = 0; j < dataChildren.getLength(); j++) {
                if (dataChildren.item(j).getNodeType() == Node.ELEMENT_NODE) {
                    hasChildElement = true;
                    break;
                }
            }

            if (!hasChildElement) {
                String text = dataElement.getTextContent();
                if (text != null && !text.trim().isEmpty() && attrName != null) {
                    consumer.accept(attrName, text.trim());
                }
                continue;
            }

            populateStructuredData(dataElement, attrName, consumer, structuredData);
        }

        for (Map.Entry<String, StringBuilder> entry : structuredData.entrySet()) {
            consumer.accept(entry.getKey(), entry.getValue().toString().trim());
        }
    }

    private void populateStructuredData(Element dataElement, String attrName, DataConsumer consumer,
                                         Map<String, StringBuilder> structuredData) {
        collectLabelElements(dataElement, structuredData);
        collectUmlClassModel(dataElement, structuredData);
    }

    private void collectLabelElements(Node node, Map<String, StringBuilder> collected) {
        NodeList children = node.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() != Node.ELEMENT_NODE) {
                continue;
            }
            Element element = (Element) child;
            String localName = element.getLocalName();
            if ("NodeLabel".equals(localName) || "AttributeLabel".equals(localName) || "EdgeLabel".equals(localName)) {
                appendText(collected, localName, element.getTextContent());
            }
            collectLabelElements(element, collected);
        }
    }

    private void collectUmlClassModel(Element element, Map<String, StringBuilder> collected) {
        if ("UMLClassModel".equals(element.getLocalName())) {
            String className = element.getAttribute("className");
            if (className != null && !className.isEmpty()) {
                appendText(collected, "className", className);
            }
            Element attributesElement = getFirstChildElement(element, "UMLClassModel.attributes");
            if (attributesElement != null) {
                collectUmlStringArray(attributesElement, collected, "attributes");
            }
            Element operationsElement = getFirstChildElement(element, "UMLClassModel.operations");
            if (operationsElement != null) {
                collectUmlStringArray(operationsElement, collected, "attributes");
            }
        }

        NodeList children = element.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() == Node.ELEMENT_NODE) {
                collectUmlClassModel((Element) child, collected);
            }
        }
    }

    private void collectUmlStringArray(Element arrayContainerElement, Map<String, StringBuilder> collected, String targetKey) {
        NodeList children = arrayContainerElement.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() != Node.ELEMENT_NODE) {
                continue;
            }
            Element element = (Element) child;
            if ("Array".equals(element.getLocalName())) {
                NodeList items = element.getChildNodes();
                for (int j = 0; j < items.getLength(); j++) {
                    Node item = items.item(j);
                    if (item.getNodeType() == Node.ELEMENT_NODE && "String".equals(item.getLocalName())) {
                        appendText(collected, targetKey, item.getTextContent());
                    }
                }
            }
        }
    }

    private void appendText(Map<String, StringBuilder> collected, String key, String text) {
        if (text == null) {
            return;
        }
        String trimmed = text.trim();
        if (trimmed.isEmpty()) {
            return;
        }
        StringBuilder builder = collected.computeIfAbsent(key, k -> new StringBuilder());
        if (builder.length() > 0) {
            builder.append('\n');
        }
        builder.append(trimmed);
    }

    private Element getFirstChildElement(Element parent, String localName) {
        NodeList children = parent.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node node = children.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE && localName.equals(((Element) node).getLocalName())) {
                return (Element) node;
            }
        }
        return null;
    }

    @FunctionalInterface
    private interface DataConsumer {
        void accept(String key, String value);
    }
}
