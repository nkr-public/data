package com.cdmviewer.graphml;

import java.util.LinkedHashMap;
import java.util.Map;

public class GraphMlNode {

    private final String id;
    private final Map<String, String> data = new LinkedHashMap<>();

    public GraphMlNode(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public Map<String, String> getData() {
        return data;
    }

    public void putData(String key, String value) {
        data.put(key, value);
    }

    public String getData(String key) {
        return data.get(key);
    }

    @Override
    public String toString() {
        return "GraphMlNode{id='" + id + "', data=" + data + '}';
    }
}
