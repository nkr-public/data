package com.cdmviewer.graphml;

import java.util.ArrayList;
import java.util.List;

public class GraphMlGraph {

    private final String id;
    private final String edgeDefault;
    private final List<GraphMlNode> nodes = new ArrayList<>();
    private final List<GraphMlEdge> edges = new ArrayList<>();

    public GraphMlGraph(String id, String edgeDefault) {
        this.id = id;
        this.edgeDefault = edgeDefault;
    }

    public String getId() {
        return id;
    }

    public String getEdgeDefault() {
        return edgeDefault;
    }

    public List<GraphMlNode> getNodes() {
        return nodes;
    }

    public List<GraphMlEdge> getEdges() {
        return edges;
    }

    public void addNode(GraphMlNode node) {
        nodes.add(node);
    }

    public void addEdge(GraphMlEdge edge) {
        edges.add(edge);
    }

    @Override
    public String toString() {
        return "GraphMlGraph{id='" + id + "', edgeDefault='" + edgeDefault + "', nodes=" + nodes + ", edges=" + edges + '}';
    }
}
