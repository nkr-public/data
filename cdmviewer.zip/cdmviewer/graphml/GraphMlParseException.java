package com.cdmviewer.graphml;

public class GraphMlParseException extends RuntimeException {

    public GraphMlParseException(String message) {
        super(message);
    }

    public GraphMlParseException(String message, Throwable cause) {
        super(message, cause);
    }
}
