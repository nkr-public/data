package com.cdmviewer.graphml;

import java.util.LinkedHashMap;
import java.util.Map;

public class GraphMlEdge {

    private final String id;
    private final String source;
    private final String target;
    private final Map<String, String> data = new LinkedHashMap<>();

    public GraphMlEdge(String id, String source, String target) {
        this.id = id;
        this.source = source;
        this.target = target;
    }

    public String getId() {
        return id;
    }

    public String getSource() {
        return source;
    }

    public String getTarget() {
        return target;
    }

    public Map<String, String> getData() {
        return data;
    }

    public void putData(String key, String value) {
        data.put(key, value);
    }

    public String getData(String key) {
        return data.get(key);
    }

    @Override
    public String toString() {
        return "GraphMlEdge{id='" + id + "', source='" + source + "', target='" + target + "', data=" + data + '}';
    }
}
