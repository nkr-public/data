package com.cdmviewer.connectors;

import com.cdmviewer.business.BusinessIslandDetector;
import com.cdmviewer.cdm.CdmModel;
import com.cdmviewer.cdm.Table;

import java.sql.SQLException;

/**
 * {@link SchemaConnector} for MySQL/MariaDB databases.
 * <p>
 * MySQL exposes each database as a JDBC "catalog" (schemas and catalogs are equivalent), so the schema/database name is
 * passed as the catalog when querying {@link java.sql.DatabaseMetaData}.
 */
public class MysqlConnector extends AbstractJdbcSchemaConnector
{

    @Override
    protected String resolveCatalog(DbConnectionConfig config)
    {
        return config.schema();
    }

    @Override
    protected String resolveSchema(DbConnectionConfig config)
    {
        return null;
    }

    static void main() throws SQLException
    {
        CdmModel model = new MysqlConnector().readSchema(
            new DbConnectionConfig("jdbc:mysql://localhost:3306/", "root", "root", "car2"));
        BusinessIslandDetector.Result groups =
            BusinessIslandDetector.detect(model, Table::getId, relation -> relation.getSourceTable(),
                relation -> relation.getTargetTable(), table -> false, relation -> 1.0, 1.0);
        System.out.println(model);
    }
}
