package com.cdmviewer.connectors;

import com.cdmviewer.cdm.CdmModel;
import com.cdmviewer.cdm.Column;
import com.cdmviewer.cdm.ColumnCategory;
import com.cdmviewer.cdm.Relation;
import com.cdmviewer.cdm.Table;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * Base class for JDBC based {@link SchemaConnector} implementations (MySQL, Oracle, ...).
 * It relies solely on {@link DatabaseMetaData} so that the same logic can be reused for
 * every relational database exposing a standard JDBC driver.
 */
public abstract class AbstractJdbcSchemaConnector implements SchemaConnector {

    /**
     * Returns the JDBC catalog to use when querying {@link DatabaseMetaData}, or {@code null}
     * if the database uses schemas instead of catalogs (e.g. Oracle).
     */
    protected abstract String resolveCatalog(DbConnectionConfig config);

    /**
     * Returns the JDBC schema to use when querying {@link DatabaseMetaData}, or {@code null}
     * if the database uses catalogs instead of schemas (e.g. MySQL).
     */
    protected abstract String resolveSchema(DbConnectionConfig config);

    @Override
    public CdmModel readSchema(DbConnectionConfig config) throws SQLException {
        try (Connection connection = DriverManager.getConnection(config.url(), config.username(), config.password())) {
            return readSchema(connection, config);
        }
    }

    public CdmModel readSchema(Connection connection, DbConnectionConfig config) throws SQLException {
        CdmModel model = new CdmModel();
        DatabaseMetaData metaData = connection.getMetaData();
        String catalog = resolveCatalog(config);
        String schema = resolveSchema(config);

        try (ResultSet tables = metaData.getTables(catalog, schema, "%", new String[] {"TABLE"})) {
            while (tables.next()) {
                String tableName = tables.getString("TABLE_NAME");
                Table table = buildTable(metaData, catalog, schema, tableName);
                model.addTable(table);
            }
        }

        for (Table table : model.getTables()) {
            for (Relation relation : buildRelations(metaData, catalog, schema, table.getTable()).values()) {
                model.addRelation(relation);
            }
        }

        return model;
    }

    private Table buildTable(DatabaseMetaData metaData, String catalog, String schema, String tableName) throws SQLException {
        Table table = new Table(tableName, tableName);

        Set<String> primaryKeyColumns = new HashSet<>();
        try (ResultSet primaryKeys = metaData.getPrimaryKeys(catalog, schema, tableName)) {
            while (primaryKeys.next()) {
                primaryKeyColumns.add(primaryKeys.getString("COLUMN_NAME"));
            }
        }

        Set<String> foreignKeyColumns = new HashSet<>();
        try (ResultSet importedKeys = metaData.getImportedKeys(catalog, schema, tableName)) {
            while (importedKeys.next()) {
                foreignKeyColumns.add(importedKeys.getString("FKCOLUMN_NAME"));
            }
        }

        Map<String, Set<String>> uniqueIndexColumns = new LinkedHashMap<>();
        Set<String> indexedColumns = new HashSet<>();
        try (ResultSet indexInfo = metaData.getIndexInfo(catalog, schema, tableName, false, true)) {
            while (indexInfo.next()) {
                String columnName = indexInfo.getString("COLUMN_NAME");
                if (columnName == null) {
                    continue;
                }
                indexedColumns.add(columnName);
                if (!indexInfo.getBoolean("NON_UNIQUE")) {
                    String indexName = indexInfo.getString("INDEX_NAME");
                    uniqueIndexColumns.computeIfAbsent(indexName, ignored -> new LinkedHashSet<>()).add(columnName);
                }
            }
        }

        try (ResultSet columns = metaData.getColumns(catalog, schema, tableName, "%")) {
            while (columns.next()) {
                String columnName = columns.getString("COLUMN_NAME");
                String type = buildTypeName(columns);
                ColumnCategory category = resolveCategory(columnName, primaryKeyColumns, foreignKeyColumns, indexedColumns);
                boolean foreignKey = foreignKeyColumns.contains(columnName);
                table.addColumn(new Column(columnName, type, category, foreignKey));
            }
        }

        table.setPrimaryKey(Set.copyOf(primaryKeyColumns));

        List<Set<String>> uniqueKeys = new ArrayList<>();
        for (Set<String> columnsInIndex : uniqueIndexColumns.values()) {
            if (!columnsInIndex.equals(primaryKeyColumns)) {
                uniqueKeys.add(Set.copyOf(columnsInIndex));
            }
        }
        table.setUniqueKeys(List.copyOf(uniqueKeys));

        return table;
    }

    private String buildTypeName(ResultSet columns) throws SQLException {
        String typeName = columns.getString("TYPE_NAME");
        int columnSize = columns.getInt("COLUMN_SIZE");
        if (columnSize > 0 && requiresSize(typeName)) {
            return typeName + "(" + columnSize + ")";
        }
        return typeName;
    }

    private boolean requiresSize(String typeName) {
        if (typeName == null) {
            return false;
        }
        String upper = typeName.toUpperCase();
        return upper.contains("CHAR") || upper.contains("DECIMAL") || upper.contains("NUMBER") || upper.contains("NUMERIC");
    }

    private ColumnCategory resolveCategory(String columnName, Set<String> primaryKeyColumns,
                                            Set<String> foreignKeyColumns, Set<String> indexedColumns) {
        if (primaryKeyColumns.contains(columnName)) {
            return ColumnCategory.ID;
        }
        if (foreignKeyColumns.contains(columnName)) {
            return ColumnCategory.EXTERNAL;
        }
        if (indexedColumns.contains(columnName)) {
            return ColumnCategory.INDEX;
        }
        return ColumnCategory.NONE;
    }

    private Map<String, Relation> buildRelations(DatabaseMetaData metaData, String catalog, String schema, String tableName)
            throws SQLException {
        Map<String, String> sourceTables = new LinkedHashMap<>();
        Map<String, String> targetTables = new LinkedHashMap<>();
        Map<String, Map<Integer, String>> sourceColumnsBySequence = new LinkedHashMap<>();
        Map<String, Map<Integer, String>> targetColumnsBySequence = new LinkedHashMap<>();

        try (ResultSet importedKeys = metaData.getImportedKeys(catalog, schema, tableName)) {
            while (importedKeys.next()) {
                String fkName = importedKeys.getString("FK_NAME");
                String sourceTable = importedKeys.getString("FKTABLE_NAME");
                String targetTable = importedKeys.getString("PKTABLE_NAME");
                String key = fkName != null ? fkName : sourceTable + "->" + targetTable;
                int keySequence = importedKeys.getInt("KEY_SEQ");

                sourceTables.putIfAbsent(key, sourceTable);
                targetTables.putIfAbsent(key, targetTable);
                sourceColumnsBySequence.computeIfAbsent(key, ignored -> new TreeMap<>())
                        .put(keySequence, importedKeys.getString("FKCOLUMN_NAME"));
                targetColumnsBySequence.computeIfAbsent(key, ignored -> new TreeMap<>())
                        .put(keySequence, importedKeys.getString("PKCOLUMN_NAME"));
            }
        }

        Map<String, Relation> relations = new LinkedHashMap<>();
        for (String key : sourceTables.keySet()) {
            List<String> sourceColumns = List.copyOf(sourceColumnsBySequence.get(key).values());
            List<String> targetColumns = List.copyOf(targetColumnsBySequence.get(key).values());
            relations.put(key, new Relation(key, key, sourceTables.get(key), targetTables.get(key), "n", "1",
                    sourceColumns, targetColumns));
        }
        return relations;
    }
}
