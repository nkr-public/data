package com.cdmviewer.connectors;

import com.cdmviewer.cdm.CdmModel;

import java.sql.SQLException;

/**
 * A connector is able to introspect a relational database schema (tables, columns,
 * primary/foreign keys, indexes) and build a {@link CdmModel} that can then be
 * exported to JSON via {@link com.cdmviewer.cdm.CdmModelJsonWriter}.
 */
public interface SchemaConnector {

    CdmModel readSchema(DbConnectionConfig config) throws SQLException;
}
