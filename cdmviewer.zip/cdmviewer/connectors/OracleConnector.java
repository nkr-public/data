package com.cdmviewer.connectors;

/**
 * {@link SchemaConnector} for Oracle databases.
 * <p>
 * Oracle exposes each user/schema as a JDBC "schema" (there is no catalog concept),
 * so the schema name is passed as the schema when querying {@link java.sql.DatabaseMetaData}.
 */
public class OracleConnector extends AbstractJdbcSchemaConnector {

    @Override
    protected String resolveCatalog(DbConnectionConfig config) {
        return null;
    }

    @Override
    protected String resolveSchema(DbConnectionConfig config) {
        String schema = config.schema();
        return schema != null ? schema.toUpperCase() : null;
    }

    static void main()
    {

    }
}
