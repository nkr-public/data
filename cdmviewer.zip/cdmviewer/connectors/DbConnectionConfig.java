package com.cdmviewer.connectors;

/**
 * Connection settings used by {@link SchemaConnector} implementations to reach a
 * relational database (MySQL, Oracle, ...).
 */
public record DbConnectionConfig(String url, String username, String password, String schema) {
}
