# Architecture générique Frontend / Backend

> Document d'accompagnement du diagramme `architecture.svg` (diagramme en anglais, explications en français).
> Le diagramme complet est un SVG autonome (1200 px de large, `viewBox` 0 0 1200 4980) organisé en panneaux empilés verticalement.
> Chaque panneau est également disponible sous forme de **SVG indépendant** dans le dossier [`svg/`](./svg/) et est inséré dans la section correspondante ci-dessous.

| Fichier | Section |
|---|---|
| [`architecture.svg`](./architecture.svg) | Diagramme complet (tous les panneaux) |
| [`svg/00-legend.svg`](./svg/00-legend.svg) | Légende |
| [`svg/01-frontend.svg`](./svg/01-frontend.svg) | Panneau 1 — Frontend |
| [`svg/01b-mfe-layers.svg`](./svg/01b-mfe-layers.svg) | Panneau 1b — Couches internes d'un micro-frontend |
| [`svg/02-backend.svg`](./svg/02-backend.svg) | Panneau 2 — Backend microservices |
| [`svg/03-hexagonal.svg`](./svg/03-hexagonal.svg) | Panneau 3 — Architecture hexagonale |
| [`svg/04-caches.svg`](./svg/04-caches.svg) | Panneau 4 — Caches L1 / L2 |
| [`svg/05-invalidation.svg`](./svg/05-invalidation.svg) | Panneau 5 — Écritures et invalidation |
| [`svg/06-connectors.svg`](./svg/06-connectors.svg) | Panneau 6 — Connecteurs externes |
| [`svg/07-devops.svg`](./svg/07-devops.svg) | Panneau 7 — DevOps CI/CD |

<details>
<summary>Afficher le diagramme complet</summary>

![Generic Frontend / Backend Architecture](./architecture.svg)

</details>

---

## Sommaire

1. [Légende](#légende)
2. [Panneau 1 — Frontend : micro-frontends et packages partagés](#panneau-1--frontend--micro-frontends-et-packages-partagés)
3. [Panneau 1b — Couches internes d'un micro-frontend](#panneau-1b--couches-internes-dun-micro-frontend)
4. [Panneau 2 — Backend : microservices](#panneau-2--backend--microservices)
5. [Panneau 3 — Architecture hexagonale dans un microservice](#panneau-3--architecture-hexagonale-dans-un-microservice)
6. [Panneau 4 — Caches L1 et L2 (lecture cache-aside)](#panneau-4--caches-l1-et-l2-lecture-cache-aside)
7. [Panneau 5 — Écritures et invalidation des caches](#panneau-5--écritures-et-invalidation-des-caches)
8. [Panneau 6 — Connecteurs externes](#panneau-6--connecteurs-externes)
9. [Panneau 7 — Architecture DevOps : CI/CD et plateforme](#panneau-7--architecture-devops--cicd-et-plateforme)
10. [Synthèse des règles d'architecture](#synthèse-des-règles-darchitecture)

---

## Légende

![Legend](./svg/00-legend.svg)

Le diagramme distingue explicitement **flux d'exécution (runtime)** et **dépendances de code**. Chaque panneau précise dans son sous-titre lequel des deux il représente.

| Symbole (diagramme) | Signification |
|---|---|
| `Synchronous call (HTTP, runtime)` — flèche pleine noire | Appel synchrone requête/réponse (HTTP) |
| `Asynchronous event / message (runtime)` — flèche tiretée orange | Événement ou message asynchrone via un broker |
| `Code dependency (depends on)` — flèche pointillée violette | Dépendance de code : *A dépend de B* (import) |
| `Interface implementation` — flèche tiretée violette à tête creuse | Implémentation d'une interface (un adaptateur implémente un port) |
| `Pipeline stage / deployment step` — flèche verte sarcelle | Étape de pipeline CI/CD ou de déploiement |
| `Forbidden` — trait rouge barré | Relation **interdite** par l'architecture |

Palette de couleurs :

| Couleur | Usage |
|---|---|
| Bleu (`Frontend`) | Éléments frontend (Shell, micro-frontends, packages, navigateur) |
| Violet (`Business logic`) | Logique métier : services, cas d'utilisation, domaine, ports |
| Vert (`L1 cache`) | Cache local L1 (Caffeine) |
| Orange (`Redis (L2)`) | Cache partagé L2 (Redis) |
| Gris (`Infrastructure`) | Infrastructure : proxy, gateway, bases de données, broker, adaptateurs techniques |
| Sarcelle (`DevOps / CI-CD`) | Chaîne CI/CD et plateforme |

---

## Panneau 1 — Frontend : micro-frontends et packages partagés

![1. Frontend — Micro-frontends & Shared Packages](./svg/01-frontend.svg)

**Type de flèches : dépendances de code.**

### Composants

| Élément (diagramme) | Rôle |
|---|---|
| `Shell (host)` | Application hôte : navigation, routage et **composition à l'exécution** des micro-frontends, chargés comme *remotes* indépendants. |
| `Application A`, `Application B`, `Application C` | Trois micro-frontends **construits et déployés indépendamment** (React + Vite, monorepo). |
| `ui` | Bibliothèque de composants graphiques partagés. |
| `i18n` | Internationalisation (traductions, formats). |
| `config` | Configuration d'exécution (URLs, feature flags, environnement). |
| `auth` | Authentification / gestion de session et de jetons. |
| `api-client` | Clients d'API typés utilisés par les applications. |
| `api-contracts` | Contrats d'API (types, schémas, DTO) partagés entre frontend et backend. |
| `http` | Couche HTTP bas niveau (client, intercepteurs, gestion des erreurs). |

### Règles de dépendance

- Les applications **dépendent des packages partagés** (`Applications depend on shared packages`).
- `api-client` → `http` et `api-contracts`.
- `auth` → `http`.
- **Interdit** : `ui` ne doit **pas** dépendre de `api-client` ni de `http` (la bibliothèque UI reste purement présentationnelle).
- **Interdit** : les micro-frontends ne doivent **jamais s'importer directement** entre eux (`Micro-frontends must NOT import each other`). Toute collaboration passe par le Shell (routage, événements) ou par les packages partagés.

### Pourquoi

Ce découpage garantit que chaque micro-frontend peut évoluer, être testé et livré séparément, tout en mutualisant les briques transverses (UI, auth, HTTP) sans créer de couplage entre domaines fonctionnels.

---

## Panneau 1b — Couches internes d'un micro-frontend

![1b. Micro-frontend Internal Layers](./svg/01b-mfe-layers.svg)

**Type de flèches : dépendances de code (orientées vers l'intérieur).**

| Couche (diagramme) | Contenu | Dépend de |
|---|---|---|
| `Bootstrap` | Point d'entrée, exposition du *remote* (Vite), câblage des adaptateurs dans les ports. | Toutes les couches (racine de composition). |
| `Presentation` | Composants React, pages, hooks, view models. | `Application` |
| `Application` | Cas d'utilisation, orchestration, état applicatif. | `Domain`, `Ports` |
| `Domain` | Entités, objets-valeurs, règles métier — **sans framework**. | Rien |
| `Ports` | Interfaces requises par la couche Application (repositories, gateways…). | `Domain` (types) |
| `Infrastructure` | Adaptateurs concrets : `api-client`, `http`, stockage local, intégration `auth`. | **Implémente** `Ports` |

Lecture du diagramme : `Presentation → Application → Domain`, `Application → Ports`, `Infrastructure implements Ports`, `Bootstrap` dépend de tout. Le domaine est ainsi isolé de React, de Vite et des API distantes.

---

## Panneau 2 — Backend : microservices

![2. Backend — Microservices](./svg/02-backend.svg)

**Type de flèches : communication à l'exécution.**

### Chaîne d'entrée

`Browser` → (HTTPS) → `Reverse Proxy` → (HTTP) → `API Gateway` → services.

| Élément | Responsabilités |
|---|---|
| `Reverse Proxy` | Terminaison TLS, service des assets statiques, routage. |
| `API Gateway` | Authentification / autorisation, limitation de débit, routage vers N services. |

### Services et données

- `Service A`, `Service B`, `Service C` : trois microservices génériques, chacun avec **sa propre base** (`Database A/B/C`, *owned by Service X*).
- **Interdit** : un service n'accède **jamais** directement à la base d'un autre service (`No cross-service DB access`). L'accès aux données d'autrui passe par l'API du service propriétaire ou par des événements.

### Communication

| Mode | Représentation | Usage |
|---|---|---|
| Synchrone HTTP | Flèche pleine (`sync HTTP`) | Requête/réponse quand le résultat est nécessaire immédiatement. |
| Asynchrone | Flèches tiretées orange `publish` / `consume` via `Message Broker` | Intégration découplée, propagation d'événements métier. |

Le `Message Broker` fonctionne en *topics / queues*, avec livraison **at-least-once** : les consommateurs doivent donc être **idempotents**.

### Point important

Il n'existe **aucune correspondance 1:1 obligatoire** entre micro-frontends et microservices : un écran peut appeler plusieurs services, et un service peut servir plusieurs écrans (`Gateway routes to N services`).

---

## Panneau 3 — Architecture hexagonale dans un microservice

![3. Hexagonal Architecture inside a Microservice](./svg/03-hexagonal.svg)

**Type de flèches : dépendances de code et implémentations d'interfaces (la communication runtime est indiquée séparément).**

### Zones

| Zone (diagramme) | Éléments | Rôle |
|---|---|---|
| `Inbound Adapters` | `REST Controllers`, `Message Consumers`, `Scheduled Jobs` | Points d'entrée : traduisent HTTP, messages ou déclencheurs planifiés en appels aux ports entrants. |
| `Application` | `Inbound Ports`, `Use Cases`, `Outbound Ports` | Orchestration des cas d'utilisation ; définit les interfaces vers l'extérieur. |
| `Domain` | `Entities`, `Value Objects`, `Business Rules`, `Domain Events` | Cœur métier pur. |
| `Outbound Adapters` | `Persistence`, `HTTP Clients`, `Cache`, `Event Publishing` | Implémentations techniques des ports sortants. |
| `Bootstrap` | `Configuration`, `Dependency Injection` | Assemblage : instancie les adaptateurs et les injecte dans les ports. |

### Règles

- Les **`Use Cases` implémentent les `Inbound Ports`** et **dépendent des `Outbound Ports`** (jamais des adaptateurs concrets).
- Les **`Outbound Adapters` implémentent les `Outbound Ports`**.
- Les adaptateurs entrants dépendent des ports entrants, pas des cas d'utilisation concrets.
- Le **`Domain` ne dépend d'aucun framework ni d'aucune infrastructure** : ni ORM, ni HTTP, ni broker.
- Toutes les dépendances de code pointent **vers l'intérieur** (vers le domaine) ; seul `Bootstrap` connaît l'ensemble.

### Distinction code / runtime

Le diagramme sépare clairement :
- les **dépendances de code** (pointillés violets) et les **implémentations** (tirets violets à tête creuse) ;
- la **communication runtime** (flèches pleines / tiretées orange) : la base, le cache, les services externes et le broker sont atteints à l'exécution par les adaptateurs sortants.

---

## Panneau 4 — Caches L1 et L2 (lecture cache-aside)

![4. Backend L1 / L2 Caches (cache-aside read flow)](./svg/04-caches.svg)

**Type de flèches : flux d'exécution.**

### Topologie

- Deux instances du **même** microservice : `Service X — instance 1` et `Service X — instance 2`.
- Chaque instance possède son **cache local L1** (`L1 Cache (Caffeine)`).
- Les deux instances partagent un **cache L2** (`L2 Cache (Redis)`).
- La `Database` reste la **source de vérité** (`Source of Truth`).

### Orchestration

L'orchestration du cache est placée dans un **`Cached Query Adapter`**, adaptateur sortant qui **implémente un port de requête appartenant à la couche Application** (`Query Port`). Les cas d'utilisation ignorent donc l'existence du cache.

### Flux de lecture (cache-aside)

1. `Request` → recherche dans **L1** (`L1 Lookup`).
2. Sur **miss L1** → recherche dans **Redis L2** (`L2 Lookup`).
3. Sur **miss L2** → **requête base de données** (`Database Query`).
4. Après lecture en base → **peupler Redis**, puis **peupler le L1 local**.
5. Après un **hit Redis** → **peupler le L1 local**.

Redis **n'interroge jamais la base lui-même** : c'est toujours l'adaptateur qui orchestre.

### Annotations

| Cache | Caractéristiques |
|---|---|
| L1 (Caffeine) | `Short TTL`, `Bounded Size` — TTL court et taille bornée pour limiter la mémoire et les données obsolètes. |
| L2 (Redis) | `Configurable TTL`, `Keys Namespaced by Service and Tenant` — TTL configurable, clés préfixées par service et par tenant pour éviter les collisions. |

---

## Panneau 5 — Écritures et invalidation des caches

![5. Writes & Cache Invalidation — Sequence (Eventual Consistency)](./svg/05-invalidation.svg)

**Type : diagramme de séquence (runtime), étiqueté `Eventual Consistency`.**

### Participants

`Instance 1 (writer)` · `Database + Outbox` · `Outbox Relay` · `Redis (L2 + Pub/Sub)` · `Instance 2 (reader)`

### Séquence

| Étape | Action |
|---|---|
| a | Écriture des données **et** de l'événement d'invalidation **dans la même transaction** (pattern *Transactional Outbox*). |
| b | Commit de la transaction. |
| c | Invalidation de l'entrée **L1 locale** de l'instance écrivaine. |
| d | Le `Outbox Relay` lit et traite l'événement committé. |
| e | Suppression de l'entrée **Redis L2** correspondante. |
| f | Publication d'une **notification d'invalidation L1** (Redis Pub/Sub). |
| g | Les instances réceptrices (ex. `Instance 2`) invalident leur **L1 local**. |

### Garanties et limites

- Le mécanisme offre une **cohérence à terme** (*Eventual Consistency*), **pas** une cohérence stricte.
- **Note** : Redis Pub/Sub **ne rejoue pas** les notifications manquées ; les **TTL courts du L1** limitent la durée des données obsolètes.
- Le flux **n'élimine pas** les *races* de repeuplement concurrent du cache (une lecture peut recharger une ancienne valeur entre l'écriture et l'invalidation).
- Pour les lectures exigeant une **fraîcheur stricte**, effectuer une **lecture directe sur la base autoritaire** en contournant les caches (`strict freshness → read authoritative DB`).

---

## Panneau 6 — Connecteurs externes

![6. External Connectors](./svg/06-connectors.svg)

**Type de flèches : runtime.**

### Deux options

| Option | Quand l'utiliser |
|---|---|
| `Option A — Embedded Adapter` | Appels externes **simples** (HTTP sans état) : un adaptateur sortant intégré au service suffit. |
| `Option B — Standalone Connector` | **Connexions persistantes**, **protocoles spécialisés** (TCP, FIX, MQ propriétaire, WebSocket…), ou besoin de **déploiement indépendant** / cycle de vie distinct. |

### Couches internes du connecteur autonome

| Couche | Rôle |
|---|---|
| `Inbound Adapters` | Reçoit les commandes des services (API/messages). |
| `Application / Domain` | Logique du connecteur : mapping, orchestration des sessions. |
| `Protocol Adapters` | Implémentation du protocole externe et gestion de la connexion. |

Responsabilités affichées : **`Mapping`**, **`Reconnection`**, **`Timeouts`**, **`Bounded Retries`**, **`Idempotency`**.

### Connexion externe exclusive : actif / secours

- `Active Instance` détient la connexion ; `Standby Instance` est prête à reprendre.
- Coordination par **bail partagé** (`Shared lease`), par exemple via un store de coordination.
- **Fencing** (jeton de génération, verrou côté système externe…) ou protection équivalente **supportée par le système externe**.
- **Avertissement** : un bail seul **ne garantit pas** l'absence de connexions concurrentes (expiration, partition réseau, pause GC) ; la protection finale doit être assurée côté système externe.

---

## Panneau 7 — Architecture DevOps : CI/CD et plateforme

![7. DevOps Architecture — CI / CD & Platform](./svg/07-devops.svg)

**Type de flèches : étapes de pipeline / déploiement.**

### Intégration continue (CI)

`Source Control` → `Build & Unit Tests` → `Quality & Security` → `Integration / Contract Tests` → `Publish Artifacts`

| Étape | Contenu |
|---|---|
| `Source Control` | Monorepo frontend + dépôts services, revues de code, branches courtes. |
| `Build & Unit Tests` | Compilation, tests unitaires, builds affectés uniquement (monorepo). |
| `Quality & Security` | Analyse statique, lint, SAST, scan de dépendances et d'images. |
| `Integration / Contract Tests` | Tests d'intégration et tests de **contrat** (cohérents avec `api-contracts`). |
| `Publish Artifacts` | Publication versionnée des artefacts. |

### Dépôts d'artefacts

| Dépôt | Contenu |
|---|---|
| `Container Registry` | Images des microservices et connecteurs. |
| `CDN / Bucket` | Bundles des micro-frontends (*remotes*) et du Shell. |
| `Package Registry` | Packages partagés du monorepo (`ui`, `auth`, `api-contracts`…). |
| `GitOps Manifests Repo` | Manifestes Kubernetes / Helm / Kustomize par environnement. |

### Déploiement continu (CD)

`GitOps Controller` → `Dev` → `Staging` → `Production`, avec **livraison progressive** (canary / blue-green) et une boucle de retour via `Observability` (logs, métriques, traces, alertes) permettant le **rollback** automatique.

### Plateforme et infrastructure as code

| Bloc | Rôle |
|---|---|
| `Kubernetes Cluster` | Exécution des services, connecteurs, Redis et broker. |
| `Infrastructure as Code` | Terraform / équivalents pour l'infrastructure managée. |
| `Secrets & Config` | Gestion des secrets et de la configuration par environnement. |
| `Identity & Access` | IAM, OIDC, RBAC pour humains et pipelines. |
| `Cost & Governance` | Politiques, quotas, conformité, suivi des coûts. |

---

## Synthèse des règles d'architecture

| # | Règle | Panneau |
|---|---|---|
| 1 | Les micro-frontends ne s'importent jamais entre eux. | 1 |
| 2 | `ui` ne dépend ni de `api-client` ni de `http`. | 1 |
| 3 | `api-client → http, api-contracts` ; `auth → http`. | 1 |
| 4 | Le domaine (front comme back) est sans framework. | 1b, 3 |
| 5 | Chaque microservice possède ses données ; pas d'accès croisé aux bases. | 2 |
| 6 | Pas de correspondance 1:1 imposée entre micro-frontends et microservices. | 2 |
| 7 | Les cas d'utilisation implémentent les ports entrants et dépendent des ports sortants ; les adaptateurs sortants implémentent les ports sortants. | 3 |
| 8 | Cache-aside L1 (Caffeine) → L2 (Redis) → base ; la base est la source de vérité ; Redis n'interroge jamais la base. | 4 |
| 9 | Invalidation via outbox transactionnel + relay + Pub/Sub : cohérence à terme, pas stricte ; lecture directe en base pour la fraîcheur stricte. | 5 |
| 10 | Connexion externe exclusive : actif/secours avec bail **et** fencing côté système externe. | 6 |
| 11 | Livraison via pipeline CI → artefacts → GitOps → environnements, avec observabilité et rollback. | 7 |
