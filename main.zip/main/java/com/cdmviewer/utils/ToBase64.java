package com.cdmviewer.utils;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Objects;

/**
 * Utilitaire permettant d'encoder et décoder des fichiers (binaires tels que .exe, images, etc.) en Base64.
 */
public final class ToBase64 {

    private ToBase64() {
        // Constructeur privé pour classe utilitaire
    }

    /**
     * Encode un tableau d'octets en chaîne Base64.
     */
    public static String encodeToString(byte[] data) {
        Objects.requireNonNull(data, "Data array cannot be null");
        return Base64.getEncoder().encodeToString(data);
    }

    /**
     * Encode un tableau d'octets en octets Base64.
     */
    public static byte[] encode(byte[] data) {
        Objects.requireNonNull(data, "Data array cannot be null");
        return Base64.getEncoder().encode(data);
    }

    /**
     * Décode une chaîne Base64 en tableau d'octets (supporte les retours à la ligne / espaces).
     */
    public static byte[] decodeStringToBytes(String base64) {
        Objects.requireNonNull(base64, "Base64 string cannot be null");
        return Base64.getMimeDecoder().decode(base64);
    }

    /**
     * Décode un tableau d'octets Base64.
     */
    public static byte[] decode(byte[] base64Data) {
        Objects.requireNonNull(base64Data, "Base64 data array cannot be null");
        return Base64.getMimeDecoder().decode(base64Data);
    }

    /**
     * Encode un fichier en chaîne Base64.
     */
    public static String encodeFileToString(Path path) throws IOException {
        Objects.requireNonNull(path, "Path cannot be null");
        byte[] bytes = Files.readAllBytes(path);
        return Base64.getEncoder().encodeToString(bytes);
    }

    public static String encodeFileToString(File file) throws IOException {
        Objects.requireNonNull(file, "File cannot be null");
        return encodeFileToString(file.toPath());
    }

    public static String encodeFileToString(String filePath) throws IOException {
        Objects.requireNonNull(filePath, "filePath cannot be null");
        return encodeFileToString(Paths.get(filePath));
    }

    /**
     * Décode une chaîne Base64 et écrit le résultat dans un fichier.
     */
    public static void decodeStringToFile(String base64, Path outputPath) throws IOException {
        Objects.requireNonNull(outputPath, "outputPath cannot be null");
        byte[] decoded = decodeStringToBytes(base64);
        ensureParentDirectoryExists(outputPath);
        Files.write(outputPath, decoded);
    }

    public static void decodeStringToFile(String base64, File outputFile) throws IOException {
        Objects.requireNonNull(outputFile, "outputFile cannot be null");
        decodeStringToFile(base64, outputFile.toPath());
    }

    public static void decodeStringToFile(String base64, String outputFilePath) throws IOException {
        Objects.requireNonNull(outputFilePath, "outputFilePath cannot be null");
        decodeStringToFile(base64, Paths.get(outputFilePath));
    }

    /**
     * Encode un flux d'entrée en Base64 vers un flux de sortie.
     */
    public static void encode(InputStream in, OutputStream out) throws IOException {
        Objects.requireNonNull(in, "InputStream cannot be null");
        Objects.requireNonNull(out, "OutputStream cannot be null");
        try (OutputStream encoderOut = Base64.getEncoder().wrap(out)) {
            in.transferTo(encoderOut);
            encoderOut.flush();
        }
    }

    /**
     * Décode un flux d'entrée Base64 vers un flux de sortie binaire.
     */
    public static void decode(InputStream in, OutputStream out) throws IOException {
        Objects.requireNonNull(in, "InputStream cannot be null");
        Objects.requireNonNull(out, "OutputStream cannot be null");
        try (InputStream decoderIn = Base64.getMimeDecoder().wrap(in)) {
            decoderIn.transferTo(out);
            out.flush();
        }
    }

    /**
     * Encode un fichier d'entrée en Base64 et écrit le résultat dans le fichier de sortie (mode flux).
     */
    public static void encodeFile(Path inputPath, Path outputPath) throws IOException {
        Objects.requireNonNull(inputPath, "inputPath cannot be null");
        Objects.requireNonNull(outputPath, "outputPath cannot be null");
        ensureParentDirectoryExists(outputPath);
        try (InputStream in = new BufferedInputStream(Files.newInputStream(inputPath));
             OutputStream out = new BufferedOutputStream(Files.newOutputStream(outputPath))) {
            encode(in, out);
        }
    }

    public static void encodeFile(File inputFile, File outputFile) throws IOException {
        Objects.requireNonNull(inputFile, "inputFile cannot be null");
        Objects.requireNonNull(outputFile, "outputFile cannot be null");
        encodeFile(inputFile.toPath(), outputFile.toPath());
    }

    public static void encodeFile(String inputPath, String outputPath) throws IOException {
        Objects.requireNonNull(inputPath, "inputPath cannot be null");
        Objects.requireNonNull(outputPath, "outputPath cannot be null");
        encodeFile(Paths.get(inputPath), Paths.get(outputPath));
    }

    /**
     * Décode un fichier Base64 d'entrée et écrit le fichier binaire de sortie (mode flux).
     */
    public static void decodeFile(Path inputPath, Path outputPath) throws IOException {
        Objects.requireNonNull(inputPath, "inputPath cannot be null");
        Objects.requireNonNull(outputPath, "outputPath cannot be null");
        ensureParentDirectoryExists(outputPath);
        try (InputStream in = new BufferedInputStream(Files.newInputStream(inputPath));
             OutputStream out = new BufferedOutputStream(Files.newOutputStream(outputPath))) {
            decode(in, out);
        }
    }

    public static void decodeFile(File inputFile, File outputFile) throws IOException {
        Objects.requireNonNull(inputFile, "inputFile cannot be null");
        Objects.requireNonNull(outputFile, "outputFile cannot be null");
        decodeFile(inputFile.toPath(), outputFile.toPath());
    }

    public static void decodeFile(String inputPath, String outputPath) throws IOException {
        Objects.requireNonNull(inputPath, "inputPath cannot be null");
        Objects.requireNonNull(outputPath, "outputPath cannot be null");
        decodeFile(Paths.get(inputPath), Paths.get(outputPath));
    }

    private static void ensureParentDirectoryExists(Path path) throws IOException {
        Path parent = path.getParent();
        if (parent != null && !Files.exists(parent)) {
            Files.createDirectories(parent);
        }
    }

    /**
     * Point d'entrée CLI pour encoder ou décoder un fichier en ligne de commande.
     * Usage : java com.cdmviewer.utils.ToBase64 <encode|decode> <sourceFile> [destinationFile]
     */
//    public static void main(String[] args) {
//        if (args == null || args.length < 2) {
//            printUsage();
//            return;
//        }
//
//        String mode = args[0].toLowerCase();
//        Path sourcePath = Paths.get(args[1]);
//
//        if (!Files.exists(sourcePath)) {
//            System.err.println("Erreur: Le fichier source n'existe pas : " + sourcePath);
//            return;
//        }
//
//        try {
//            if ("encode".equals(mode) || "-e".equals(mode) || "--encode".equals(mode) || "e".equals(mode)) {
//                Path destPath = args.length >= 3 ? Paths.get(args[2]) : Paths.get(args[1] + ".b64");
//                encodeFile(sourcePath, destPath);
//                System.out.println("Encodage réussi vers : " + destPath);
//            } else if ("decode".equals(mode) || "-d".equals(mode) || "--decode".equals(mode) || "d".equals(mode)) {
//                Path destPath;
//                if (args.length >= 3) {
//                    destPath = Paths.get(args[2]);
//                } else {
//                    String srcName = sourcePath.getFileName().toString();
//                    String defaultName = srcName.endsWith(".b64") ? srcName.substring(0, srcName.length() - 4) : srcName + ".out";
//                    Path parent = sourcePath.getParent();
//                    destPath = parent != null ? parent.resolve(defaultName) : Paths.get(defaultName);
//                }
//                decodeFile(sourcePath, destPath);
//                System.out.println("Décodage réussi vers : " + destPath);
//            } else {
//                System.err.println("Mode inconnu : " + mode);
//                printUsage();
//            }
//        } catch (Exception e) {
//            System.err.println("Erreur lors de l'opération : " + e.getMessage());
//            e.printStackTrace();
//        }
//    }

    private static void printUsage() {
        System.out.println("Usage: ToBase64 <encode|decode> <fichier_source> [fichier_destination]");
        System.out.println("Exemples :");
        System.out.println("  ToBase64 encode mon_executable.exe mon_executable.exe.b64");
        System.out.println("  ToBase64 decode mon_executable.exe.b64 mon_executable.exe");
    }

    static void main() throws IOException
    {

 encodeFile(new File("D:\\projects\\tools\\cdmViewer\\frontend\\src-tauri\\target\\release\\cdmviewer.exe"),
     new File("D:\\projects\\tools\\cdmViewer\\frontend\\src-tauri\\target\\release\\cdmviewer.b64.txt"));
    }
}
