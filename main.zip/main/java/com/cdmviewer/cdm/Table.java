package com.cdmviewer.cdm;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Getter
public class Table {

    private final String id;
    private final String table;
    private final List<Column> columns = new ArrayList<>();
    @Setter
    private Set<String> primaryKey;
    @Setter
    private List<Set<String>> uniqueKeys;
    @Setter
    private long nbRows;

    public Table(String id, String table) {
        this.id = id;
        this.table = table;
    }

    public void addColumn(Column column) {
        columns.add(column);
    }

    public String getTable() {
        return table;
    }

    @Override
    public String toString() {
        return "Table{id='" + id + "', table='" + table + "', columns=" + columns
                + ", primaryKey=" + primaryKey + ", uniqueKeys=" + uniqueKeys + '}';
    }
}
