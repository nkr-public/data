package com.cdmviewer.cdm;

import lombok.Getter;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Getter
public class CdmModel
{

    protected List<Relation> relations = new ArrayList<>();

    protected  Set<Table> tables = new HashSet<>();


    public void addTable(Table table)
    {
        tables.add(table);
    }

    public void addRelation(Relation relation)
    {
        relations.add(relation);
    }

    public CdmModel filterByPrefixSuffix(String prefix, String suffix)
    {
        CdmModel filteredModel = new CdmModel();
        Set<String> retainedTableNames = new HashSet<>();

        for (Table table : tables) {
            String tableName = table.getTable();
            boolean matchPrefix = (prefix == null) || (tableName != null && !tableName.toLowerCase().startsWith(prefix));
            boolean matchSuffix = (suffix == null) || (tableName != null && !tableName.toLowerCase().endsWith(suffix));

            if (matchPrefix && matchSuffix) {
                filteredModel.addTable(table);
                if (tableName != null) {
                    retainedTableNames.add(tableName);
                }
            }
        }

        for (Relation relation : relations) {
            if (relation.getSourceTable() != null && relation.getTargetTable() != null && retainedTableNames.contains(
                relation.getSourceTable()) && retainedTableNames.contains(relation.getTargetTable())) {
                filteredModel.addRelation(relation);
            }
        }

        return filteredModel;
    }

    @Override
    public String toString()
    {
        return "CdmModel{tables=" + tables + ", relations=" + relations + '}';
    }
}
