package com.cdmviewer.cdm;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Getter
@Setter
public class CdmModelDto extends CdmModel
{
    public CdmModelDto()
    {
    }

    private List<List<String>> clusters;

    public CdmModelDto(CdmModel cached, List<Set<String>> sets)
    {
        super();
        clusters =  sets.stream().filter(set -> set.size() > 1).map(set -> {
            List<String> cluster = new ArrayList<>(set);
            cluster.sort(String::compareTo);
            return cluster;
        }).toList();
        tables = cached.getTables();
        relations = cached.getRelations();
        ArrayList<String> orphansTables =
            sets.stream().filter(set -> set.size() == 1).flatMap(Set::stream).distinct().sorted(
                String::compareTo).collect(Collectors.toCollection(ArrayList::new));
        clusters= new ArrayList<>(clusters);
        clusters.add(orphansTables);
    }
}
