package com.cdmviewer.schema;

import java.util.List;
import java.util.Set;

public record SchemaMap(
    List<TableInfo> tables,
    List<RelationInfo> relations,
    List<Island> islands,
    List<String> sharedTableIds,
    List<IslandDependency> islandDependencies,
    SchemaStats stats,
    List<Diagnostic> diagnostics
) {
    public List<Set<String>> islandTables() {
        return islands.stream().map(Island::getAllTable).toList();
    }
}
