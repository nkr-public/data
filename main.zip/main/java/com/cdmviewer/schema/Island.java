package com.cdmviewer.schema;

import lombok.Getter;
import lombok.Setter;

import java.util.*;
import java.util.stream.Collectors;

@Getter @Setter
public final class Island
{
    private String id;

    private String proposedName;

    private boolean nameOverridden;
    private  int totalTables;

    private List<String> tableIds;

    private Map<String, Set<RelationInfo>> dependsOn;

    public Island(String id, String proposedName, boolean nameOverridden, List<String> tableIds,
        Map<String, Set<RelationInfo>> dependsOn)
    {
        this.id = id;
        this.proposedName = proposedName;
        this.nameOverridden = nameOverridden;
        this.tableIds = tableIds;
        this.dependsOn = dependsOn;
    }

    public Island(String id, String proposedName, boolean nameOverridden, List<String> tableIds)
    {
        this(id, proposedName, nameOverridden, tableIds, Map.of());
    }

    public Set<String> getAllTable()
    {
        Set<String> result = new HashSet<>(tableIds);
        result.addAll(tableIds);
        Set<String> rr = dependsOn.values().stream().flatMap(Collection::stream).map(relationInfo -> {
            ArrayList<String> r = new ArrayList<>();
            r.add(relationInfo.sourceTableId());
            r.add(relationInfo.targetTableId());
            return r;
        }).flatMap(List::stream).collect(Collectors.toSet());
        result.addAll(rr);
        return result;
    }

    public String id()
    {
        return id;
    }

    public String proposedName()
    {
        return proposedName;
    }

    public boolean nameOverridden()
    {
        return nameOverridden;
    }

    public List<String> tableIds()
    {
        return tableIds;
    }

    public Map<String, Set<RelationInfo>> dependsOn()
    {
        return dependsOn;
    }


    public void rename(int i)
    {
        proposedName = "Clsuter: " + i;
        totalTables = getAllTable().size();
        id = "Clsuter: " + i;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (obj == this)
            return true;
        if (obj == null || obj.getClass() != this.getClass())
            return false;
        var that = (Island) obj;
        return Objects.equals(this.id, that.id) && Objects.equals(this.proposedName,
            that.proposedName) && this.nameOverridden == that.nameOverridden && Objects.equals(this.tableIds,
            that.tableIds) && Objects.equals(this.dependsOn, that.dependsOn);
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(id, proposedName, nameOverridden, tableIds, dependsOn);
    }

    @Override
    public String toString()
    {
        return "Island[" + "id=" + id + ", " + "proposedName=" + proposedName + ", " + "nameOverridden=" + nameOverridden + ", " + "tableIds=" + tableIds + ", " + "dependsOn=" + dependsOn + ']';
    }


}
