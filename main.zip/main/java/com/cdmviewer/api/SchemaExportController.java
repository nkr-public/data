package com.cdmviewer.api;

import com.cdmviewer.cdm.CdmModel;
import com.cdmviewer.cdm.CdmModelDto;
import com.cdmviewer.connectors.DbConnectionConfig;
import com.cdmviewer.connectors.MysqlConnector;
import com.cdmviewer.connectors.OracleConnector;
import com.cdmviewer.connectors.SchemaConnector;
import com.cdmviewer.schema.MappingMode;
import com.cdmviewer.schema.MappingOptions;
import com.cdmviewer.schema.SchemaMap;
import com.cdmviewer.schema.SchemaMappingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.sql.SQLException;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Exposes an endpoint able to connect to a MySQL or Oracle database, introspect its schema (tables, columns,
 * primary/foreign keys) and return the resulting CDM model as JSON.
 */
@RestController
public class SchemaExportController
{

    /**
     * Cache of previously read schemas, keyed by the (url, schema) pair of the request, to avoid re-introspecting the
     * same database on every call.
     */
    private final Map<CacheKey, CdmModelDto> schemaCache = new ConcurrentHashMap<>();

    @PostMapping ("/api/schema/export")
    public ResponseEntity<CdmModelDto> exportSchema(@RequestBody SchemaExportRequest request)
    {
        CacheKey cacheKey = new CacheKey(request.url(), request.schema());
        CdmModelDto cached = schemaCache.get(cacheKey);

        if (cached != null) {
            return ResponseEntity.ok(cached);
        }

        SchemaConnector connector = resolveConnector(request.type());
        DbConnectionConfig config =
            new DbConnectionConfig(request.url(), request.username(), request.password(), request.schema());

        try {
            CdmModel model = connector.readSchema(config);
            CdmModelDto dto = toDto(model);
            schemaCache.put(cacheKey, dto);
            return ResponseEntity.ok(dto);
        } catch (SQLException e) {
            throw new IllegalStateException("Unable to read schema: " + e.getMessage(), e);
        }
    }

    private CdmModelDto toDto(CdmModel cached)
    {
        //cached = cached.filterByPrefixSuffix("ref_", "flyway_schema_history");
        MappingOptions options =
            new MappingOptions(MappingMode.TOLERANT, Set.of("created_at", "updated_at"), 1, 100, 1.0, 1.0,
                java.util.Map.of(), Set.of("STATUS"), java.util.Map.of(), java.util.Map.of());

        SchemaMap schemaMap = new SchemaMappingService().map(cached, options);
        return new CdmModelDto(cached, schemaMap.islandTables());
    }

    private record CacheKey(String url, String schema)
    {
    }

    private SchemaConnector resolveConnector(String type)
    {
        if (type == null) {
            throw new IllegalArgumentException("Connector type is required (mysql or oracle)");
        }
        switch(type.toLowerCase()) {
            case "mysql", "mariadb" -> {
                return new MysqlConnector();
            }
            case "oracle" -> {
                return new OracleConnector();
            }
            default -> throw new IllegalArgumentException("Unsupported connector type: " + type);
        }
    }
}
