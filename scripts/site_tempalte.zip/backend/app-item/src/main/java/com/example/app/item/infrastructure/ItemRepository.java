package com.example.app.item.infrastructure;

import com.example.app.item.domain.Item;
import com.example.app.jooq.tables.records.ItemRecord;
import org.jooq.Configuration;
import org.jooq.impl.DAOImpl;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static com.example.app.jooq.Tables.ITEM;

@Repository
public class ItemRepository extends DAOImpl<ItemRecord, Item, Long>
{
    protected ItemRepository(Configuration configuration)
    {
        super(ITEM, Item.class, configuration);
    }

    @Override
    public Long getId(Item object)
    {
        return object.id();
    }

    public List<Item> findByOwner(long ownerId)
    {
        return ctx().selectFrom(ITEM).where(ITEM.OWNER_ID.eq(ownerId)).orderBy(ITEM.ID.desc()).fetch(this::toDomain);
    }

    public Optional<Item> findByIdAndOwner(long id, long ownerId)
    {
        return ctx().selectFrom(ITEM).where(ITEM.ID.eq(id)).and(ITEM.OWNER_ID.eq(ownerId)).fetchOptional(
            this::toDomain);
    }

    public Item create(long ownerId, String name, String description)
    {
        ItemRecord record = ctx().newRecord(ITEM);
        record.setOwnerId(ownerId);
        record.setName(name);
        record.setDescription(description);
        record.store();
        record.refresh();
        return toDomain(record);
    }

    public Optional<Item> update(long id, long ownerId, String name, String description)
    {
        int updated = ctx().update(ITEM).set(ITEM.NAME, name).set(ITEM.DESCRIPTION, description).set(
            ITEM.UPDATED_AT, LocalDateTime.now()).where(ITEM.ID.eq(id)).and(ITEM.OWNER_ID.eq(ownerId)).execute();
        return updated == 0 ? Optional.empty() : findByIdAndOwner(id, ownerId);
    }

    public boolean deleteByIdAndOwner(long id, long ownerId)
    {
        return ctx().deleteFrom(ITEM).where(ITEM.ID.eq(id)).and(ITEM.OWNER_ID.eq(ownerId)).execute() > 0;
    }

    private Item toDomain(ItemRecord r)
    {
        return new Item(r.getId(), r.getOwnerId(), r.getName(), r.getDescription(), r.getCreatedAt(),
            r.getUpdatedAt());
    }
}
