package com.example.app.shared.config;

import org.springframework.boot.autoconfigure.jooq.DefaultConfigurationCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration (proxyBeanMethods = false)
public class JooqMappingConfiguration {

    @Bean
    public DefaultConfigurationCustomizer recordMappingCustomizer() {
        return configuration -> configuration.settings()
            .withMapRecordComponentParameterNames(true);
    }
}
