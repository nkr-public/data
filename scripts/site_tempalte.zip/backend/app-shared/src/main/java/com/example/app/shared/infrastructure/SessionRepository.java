package com.example.app.shared.infrastructure;

import com.example.app.jooq.tables.AuthSession;
import com.example.app.jooq.tables.records.AuthSessionRecord;
import com.example.app.shared.security.Session;
import org.jooq.Configuration;
import org.jooq.impl.DAOImpl;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;

import static com.example.app.jooq.Tables.AUTH_SESSION;

@Repository
public class SessionRepository extends DAOImpl<AuthSessionRecord, Session, Long>
{

    protected SessionRepository(Configuration configuration)
    {
        super(AuthSession.AUTH_SESSION, Session.class, configuration);
    }

    @Override
    public Long getId(Session session)
    {
        return session.id();
    }

    public Session save(Session session)
    {
        AuthSessionRecord record = ctx().newRecord(AUTH_SESSION);
        record.setUserId(session.userId());
        record.setTokenHash(session.tokenHash());
        record.setExpiresAt(session.expiresAt());
        record.setCreatedAt(LocalDateTime.now());
        record.setDeviceName(session.deviceName());
        record.setIpAddress(session.ipAddress());
        record.setUserAgentHash(session.userAgentHash());
        record.store();
        return toDomain(record);
    }

    public Optional<Session> findByTokenHash(String tokenHash)
    {
        return ctx().selectFrom(AUTH_SESSION).where(AUTH_SESSION.TOKEN_HASH.eq(tokenHash)).fetchOptional().map(
            this::toDomain);
    }

    public String getOrCreateCsrfToken(String tokenHash, String candidate)
    {
        var csrfToken = AUTH_SESSION.CSRF_TOKEN;// DSL.field(DSL.name("CSRF_TOKEN"), String.class);
        var validSession = AUTH_SESSION.TOKEN_HASH.eq(tokenHash).and(AUTH_SESSION.REVOKED_AT.isNull()).and(
            AUTH_SESSION.EXPIRES_AT.gt(LocalDateTime.now()));
        ctx().update(AUTH_SESSION).set(AUTH_SESSION.CSRF_TOKEN, candidate).where(
            validSession.and(AUTH_SESSION.CSRF_TOKEN.isNull())).execute();
        return ctx().select(AUTH_SESSION.CSRF_TOKEN).from(AUTH_SESSION).where(validSession).fetchOne(
            AUTH_SESSION.CSRF_TOKEN);
    }

    /**
     * Met a jour la date de derniere activite. Volontairement peu appelee (uniquement au chargement depuis la base, pas
     * a chaque requete) afin d'eviter une ecriture systematique en base sur chaque appel.
     */
    public void touchLastSeen(long id)
    {
        ctx().update(AUTH_SESSION).set(AUTH_SESSION.LAST_SEEN_AT, LocalDateTime.now()).where(
            AUTH_SESSION.ID.eq(id)).execute();
    }

    public void revokeByTokenHash(String tokenHash)
    {
        ctx().update(AUTH_SESSION).set(AUTH_SESSION.REVOKED_AT, LocalDateTime.now()).where(
            AUTH_SESSION.TOKEN_HASH.eq(tokenHash)).and(AUTH_SESSION.REVOKED_AT.isNull()).execute();
    }

    public void revokeAllForUser(long userId)
    {
        ctx().update(AUTH_SESSION).set(AUTH_SESSION.REVOKED_AT, LocalDateTime.now()).where(
            AUTH_SESSION.USER_ID.eq(userId)).and(AUTH_SESSION.REVOKED_AT.isNull()).execute();
    }

    private Session toDomain(AuthSessionRecord r)
    {
        return new Session(r.getId(), r.getUserId(), r.getTokenHash(), r.getCreatedAt(), r.getExpiresAt(),
            r.getLastSeenAt(), r.getRevokedAt(), r.getDeviceName(), r.getIpAddress(), r.getUserAgentHash());
    }
}
