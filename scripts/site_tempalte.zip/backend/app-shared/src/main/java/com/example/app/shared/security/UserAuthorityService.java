package com.example.app.shared.security;

import com.example.app.jooq.Tables;
import org.jooq.DSLContext;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import java.util.List;

/** Resout les roles d'un utilisateur ("ROLE_USER", "ROLE_ADMIN"...) depuis la base. */
@Service
public class UserAuthorityService
{
    private final DSLContext dsl;

    public UserAuthorityService(DSLContext dsl)
    {
        this.dsl = dsl;
    }

    public List<GrantedAuthority> loadAuthorities(long userId)
    {
        String role = dsl.select(Tables.USER_ACCOUNT.ROLE).from(Tables.USER_ACCOUNT)
            .where(Tables.USER_ACCOUNT.ID.eq(userId)).fetchOne(Tables.USER_ACCOUNT.ROLE);
        return role == null ? List.of() : List.of(new SimpleGrantedAuthority("ROLE_" + role));
    }
}
