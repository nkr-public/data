package com.example.app.identity.infrastructure;

import com.example.app.identity.domain.AppUser;
import com.example.app.jooq.tables.UserAccount;
import com.example.app.jooq.tables.records.UserAccountRecord;
import org.jooq.Configuration;
import org.jooq.impl.DAOImpl;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;

import static com.example.app.jooq.Tables.USER_ACCOUNT;

@Repository
public class UserRepository extends DAOImpl<UserAccountRecord, AppUser, Long>
{
    protected UserRepository(Configuration configuration)
    {
        super(UserAccount.USER_ACCOUNT, AppUser.class, configuration);
    }

    @Override
    public Long getId(AppUser object)
    {
        return object.id();
    }

    public Optional<AppUser> findByUsernameOrEmail(String usernameOrEmail)
    {
        return ctx().selectFrom(USER_ACCOUNT).where(
            USER_ACCOUNT.USERNAME.eq(usernameOrEmail).or(USER_ACCOUNT.EMAIL.eq(usernameOrEmail))).and(
            USER_ACCOUNT.DELETED_AT.isNull()).fetchOptional().map(this::toDomain);
    }

    public Optional<AppUser> findById(long id)
    {
        return ctx().selectFrom(USER_ACCOUNT).where(USER_ACCOUNT.ID.eq(id)).and(
            USER_ACCOUNT.DELETED_AT.isNull()).fetchOptional().map(this::toDomain);
    }

    public boolean existsByUsername(String username)
    {
        return ctx().fetchExists(ctx().selectFrom(USER_ACCOUNT).where(USER_ACCOUNT.USERNAME.eq(username)));
    }

    public boolean existsByEmail(String email)
    {
        return ctx().fetchExists(ctx().selectFrom(USER_ACCOUNT).where(USER_ACCOUNT.EMAIL.eq(email)));
    }

    public AppUser create(String username, String email, String phone, String passwordHash)
    {
        return create(username, email, phone, passwordHash, "USER");
    }

    public AppUser create(String username, String email, String phone, String passwordHash, String role)
    {
        UserAccountRecord record = ctx().newRecord(USER_ACCOUNT);
        record.setUsername(username);
        record.setEmail(email);
        record.setPhone(phone);
        record.setPasswordHash(passwordHash);
        record.setAccountStatus("ACTIVE");
        record.setRole(role != null ? role : "USER");
        record.setFailedLoginCount(0);
        record.store();
        return toDomain(record);
    }

    public void recordSuccessfulLogin(long userId)
    {
        ctx().update(USER_ACCOUNT).set(USER_ACCOUNT.LAST_LOGIN_AT, LocalDateTime.now()).set(
            USER_ACCOUNT.FAILED_LOGIN_COUNT, 0).where(
            USER_ACCOUNT.ID.eq(userId)).execute();
    }

    public void recordFailedLogin(long userId)
    {
        ctx().update(USER_ACCOUNT).set(USER_ACCOUNT.FAILED_LOGIN_COUNT, USER_ACCOUNT.FAILED_LOGIN_COUNT.add(1)).where(USER_ACCOUNT.ID.eq(userId)).execute();
    }

    private AppUser toDomain(UserAccountRecord record)
    {
        return new AppUser(record.getId(), record.getUsername(), record.getEmail(), record.getPhone(),
            record.getPasswordHash(), record.getRole(),
            record.getAccountStatus(), record.getLastLoginAt());
    }

}
