# Template Spring Boot + React (Vite/Tauri)

Template prêt à l'emploi : authentification par **session opaque** (cookie HttpOnly + CSRF) et un service REST
d'exemple de bout en bout (`/api/v1/items`).

## Structure

```
backend/
  app-db/        migration Flyway (profil Maven)
  app-jooq/      génération du code jOOQ depuis la base
  app-shared/    sécurité, sessions, erreurs, CORS
  app-identity/  /api/auth/{register,login,logout,logout-all,me}
  app-item/      exemple de service REST (CRUD) -> à copier pour vos ressources
  app-server/    application Spring Boot + migrations (db/migration)
frontend/
  apps/web/          app React (Vite) + coquille Tauri : login, Titlebar, page Items
  packages/ui/       composants partagés (Titlebar, WindowControls, thème...)
  packages/api-client/ client HTTP + auth (useCurrentUser, AuthGuard...) + endpoints
  packages/i18n/     fr / en / ar
```

## Démarrage

Prérequis : Java 21+, MySQL (root/root par défaut, base `app` créée automatiquement), Node 20+, pnpm 9.

```
./mvnw.cmd clean install          # migre la base, génère jOOQ, compile, teste
./mvnw.cmd -pl backend/app-server spring-boot:run -Dspring-boot.run.arguments=--app.cookie.secure=false

cd frontend && pnpm install && pnpm dev     # http://localhost:3000
pnpm dev:desktop                            # variante Tauri
```

Compte de démo : `admin` / `admin123` (créé par `V1__init.sql`, à changer en production).
Configuration : `backend/.env.example`, `frontend/apps/web/.env.example`.

## Ajouter une ressource

1. Table dans une nouvelle migration `app-server/src/main/resources/db/migration/V2__....sql`
2. Copier `app-item` (domain / infrastructure / application / api), l'ajouter dans `backend/pom.xml`,
   le `pom.xml` racine et `app-server/pom.xml`
3. Ajouter les types et `createXxxApi` dans `packages/api-client`, puis la page dans `apps/web/src/app`
